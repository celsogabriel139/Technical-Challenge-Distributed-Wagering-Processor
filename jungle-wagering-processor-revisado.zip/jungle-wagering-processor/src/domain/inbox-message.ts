import { DomainError } from './wager.types';

export interface InboxMessageState { messageId: string; consumerName: string; payloadHash: string; receivedAt: Date; processedAt?: Date; }
export class InboxMessage {
  private constructor(public readonly messageId: string, public readonly consumerName: string, public readonly payloadHash: string,
    public readonly receivedAt: Date, private _processedAt?: Date) {}
  static receive(props: InboxMessageState): InboxMessage {
    if (!props.messageId || !props.consumerName || !/^[a-f0-9]{64}$/.test(props.payloadHash)) throw new DomainError('INVALID_INBOX_MESSAGE');
    return new InboxMessage(props.messageId, props.consumerName, props.payloadHash, props.receivedAt);
  }
  static rehydrate(state: InboxMessageState): InboxMessage { return new InboxMessage(state.messageId, state.consumerName, state.payloadHash, state.receivedAt, state.processedAt); }
  get processedAt(): Date | undefined { return this._processedAt; }
  isProcessed(): boolean { return this._processedAt !== undefined; }
  markProcessed(at: Date): void { if (this._processedAt) return; this._processedAt = at; }
}
