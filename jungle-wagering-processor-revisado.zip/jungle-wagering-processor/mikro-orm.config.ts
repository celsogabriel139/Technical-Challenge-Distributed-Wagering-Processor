/** MikroORM CLI entrypoint. The application imports the compiled in-src config directly. */
export { default } from './src/orm.config';
