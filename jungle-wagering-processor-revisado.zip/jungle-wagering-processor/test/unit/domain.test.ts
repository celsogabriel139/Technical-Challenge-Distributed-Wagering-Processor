import { describe, expect, test } from 'bun:test';
import { randomUUID } from 'node:crypto';
import { Money } from '../../src/domain/money';
import { Wallet } from '../../src/domain/wallet';
import { WalletLedgerEntry } from '../../src/domain/wallet-ledger-entry';
import { WagerTransaction } from '../../src/domain/wager-transaction';
import { LedgerDirection, WagerKind, WagerStatus } from '../../src/domain/wager.types';

const money = (amount: string, currency = 'BRL') => Money.from({ amount, currency });

describe('Wallet domain invariants', () => {
  test('starts at version 1 and increments only when balance changes', () => {
    const wallet = Wallet.open({ id: randomUUID(), playerId: randomUUID(), initialBalance: money('100.00') });
    expect(wallet.version).toBe(1);
    const entry = wallet.debit({ transactionId: randomUUID(), money: money('25.00') });
    expect(wallet.balance.toString()).toBe('75.00');
    expect(wallet.version).toBe(2);
    expect(entry.walletVersion).toBe(2);
    expect(entry.isBalanced()).toBe(true);
  });

  test('rejects insufficient funds and currency mismatch without mutation', () => {
    const wallet = Wallet.open({ id: randomUUID(), playerId: randomUUID(), initialBalance: money('10.00') });
    expect(() => wallet.debit({ transactionId: randomUUID(), money: money('10.01') })).toThrow('INSUFFICIENT_FUNDS');
    expect(() => wallet.credit({ transactionId: randomUUID(), money: money('1.00', 'USD') })).toThrow('CURRENCY_MISMATCH');
    expect(wallet.balance.toString()).toBe('10.00');
    expect(wallet.version).toBe(1);
  });

  test('ledger factory enforces arithmetic and immutable values', () => {
    const entry = WalletLedgerEntry.create({ id: randomUUID(), walletId: randomUUID(), transactionId: randomUUID(), direction: LedgerDirection.Credit,
      money: money('10.00'), balanceBefore: money('5.00'), balanceAfter: money('15.00'), walletVersion: 2, createdAt: new Date() });
    expect(entry.isBalanced()).toBe(true);
    expect(() => WalletLedgerEntry.create({ ...entry, id: randomUUID(), balanceAfter: money('14.99') })).toThrow('UNBALANCED_LEDGER_ENTRY');
    expect(() => WalletLedgerEntry.create({ ...entry, id: randomUUID(), balanceBefore: money('0.00'), balanceAfter: money('5.00').negate() })).toThrow('LEDGER_BALANCE_CANNOT_BE_NEGATIVE');
  });
});

describe('WagerTransaction state machine', () => {
  const props = (kind: WagerKind, ref?: string) => ({
    id: randomUUID(), providerId: 'provider-a', externalTransactionId: randomUUID(), idempotencyKey: randomUUID(),
    payloadHash: 'a'.repeat(64), walletId: randomUUID(), playerId: randomUUID(), roundId: 'round-1', gameId: 'game-1',
    kind, money: money('5.00'), referenceExternalTransactionId: ref, createdAt: new Date(),
  });

  test('rejects public OPENING and missing reversal reference', () => {
    expect(() => WagerTransaction.create(props(WagerKind.Opening) as never)).toThrow('OPENING_IS_INTERNAL');
    expect(() => WagerTransaction.create(props(WagerKind.Refund) as never)).toThrow('REFERENCE_REQUIRED');
  });

  test('rejects a self-referencing refund/rollback', () => {
    const base = props(WagerKind.Rollback, 'unused');
    expect(() => WagerTransaction.create({ ...base, externalTransactionId: 'same-id', referenceExternalTransactionId: 'same-id' })).toThrow('SELF_REFERENCE_NOT_ALLOWED');
    expect(() => WagerTransaction.create({ ...props(WagerKind.Bet), referenceExternalTransactionId: 'bet-1' })).toThrow('REFERENCE_NOT_ALLOWED_FOR_KIND');
  });

  test('permits PENDING_REFERENCE to become PROCESSED but terminal states stay terminal', () => {
    const transaction = WagerTransaction.create(props(WagerKind.Rollback, 'bet-1'));
    transaction.markPendingReference();
    expect(transaction.status).toBe(WagerStatus.PendingReference);
    transaction.markProcessed(randomUUID(), new Date());
    expect(transaction.status).toBe(WagerStatus.Processed);
    expect(() => transaction.reject('INVALID_OPERATION')).toThrow('INVALID_TRANSACTION_STATE');
  });

  test('an explicitly referenced WIN may wait for its BET while an unreferenced WIN remains valid', () => {
    const base = props(WagerKind.Win, 'bet-1');
    const pendingWin = WagerTransaction.create(base);
    pendingWin.markPendingReference();
    expect(pendingWin.status).toBe(WagerStatus.PendingReference);
    const ordinaryWin = WagerTransaction.create({ ...props(WagerKind.Win), referenceExternalTransactionId: undefined });
    expect(ordinaryWin.status).toBe(WagerStatus.Pending);
  });

  test('maps reversals to the inverse of the referenced operation', () => {
    const bet = WagerTransaction.rehydrate({ ...props(WagerKind.Bet), status: WagerStatus.Processed });
    const refund = WagerTransaction.create(props(WagerKind.Refund, 'bet-1'));
    const rollback = WagerTransaction.create(props(WagerKind.Rollback, 'bet-1'));
    expect(refund.ledgerDirectionFor(bet)).toBe(LedgerDirection.Credit);
    const win = WagerTransaction.rehydrate({ ...props(WagerKind.Win), status: WagerStatus.Processed });
    expect(rollback.ledgerDirectionFor(win)).toBe(LedgerDirection.Debit);
  });
});
