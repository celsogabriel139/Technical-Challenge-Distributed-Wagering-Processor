import { Type } from 'class-transformer';
import { IsIn, IsOptional, IsString, IsUUID, MaxLength, ValidateNested } from 'class-validator';
import { MoneyDto } from './money.dto';

export class SubmitWagerDto {
  @IsString() @MaxLength(255) providerId!: string;
  @IsString() @MaxLength(255) externalTransactionId!: string;
  @IsUUID() playerId!: string;
  @IsUUID() walletId!: string;
  @IsString() @MaxLength(255) roundId!: string;
  @IsString() @MaxLength(255) gameId!: string;
  @IsIn(['BET', 'WIN', 'LOSS', 'REFUND', 'ROLLBACK']) kind!: 'BET'|'WIN'|'LOSS'|'REFUND'|'ROLLBACK';
  @ValidateNested() @Type(() => MoneyDto) money!: MoneyDto;
  @IsOptional() @IsString() @MaxLength(255) referenceExternalTransactionId?: string;
}
