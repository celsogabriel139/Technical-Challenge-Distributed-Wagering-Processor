import { randomUUID } from 'node:crypto';
import { Money } from './money';
import { DomainError, LedgerDirection } from './wager.types';
import { WalletLedgerEntry } from './wallet-ledger-entry';

export interface WalletState {
  id: string; playerId: string; currency: string; balance: Money; version: number; createdAt: Date; updatedAt: Date;
}

export class Wallet {
  private constructor(
    public readonly id: string,
    public readonly playerId: string,
    public readonly currency: string,
    private _balance: Money,
    private _version: number,
    public readonly createdAt: Date,
    private _updatedAt: Date,
  ) {}

  static open(props: { id: string; playerId: string; initialBalance: Money; now?: Date }): Wallet {
    if (props.initialBalance.isNegative()) throw new DomainError('NEGATIVE_INITIAL_BALANCE');
    const now = props.now ?? new Date();
    return new Wallet(props.id, props.playerId, props.initialBalance.currency, props.initialBalance, 1, now, now);
  }

  /** Rehydrates committed state without replaying domain transitions. */
  static rehydrate(state: WalletState): Wallet {
    return new Wallet(state.id, state.playerId, state.currency, state.balance, state.version, state.createdAt, state.updatedAt);
  }

  get balance(): Money { return this._balance; }
  get version(): number { return this._version; }
  get updatedAt(): Date { return this._updatedAt; }

  debit(props: { transactionId: string; money: Money; now?: Date }): WalletLedgerEntry {
    this.assertPositive(props.money);
    this.assertSameCurrency(props.money);
    if (this._balance.isLessThan(props.money)) throw new DomainError('INSUFFICIENT_FUNDS');
    return this.apply(LedgerDirection.Debit, props.transactionId, props.money, props.now ?? new Date());
  }

  credit(props: { transactionId: string; money: Money; now?: Date }): WalletLedgerEntry {
    this.assertPositive(props.money);
    this.assertSameCurrency(props.money);
    return this.apply(LedgerDirection.Credit, props.transactionId, props.money, props.now ?? new Date());
  }

  private apply(direction: LedgerDirection, transactionId: string, money: Money, at: Date): WalletLedgerEntry {
    const before = this._balance;
    const after = direction === LedgerDirection.Credit ? before.add(money) : before.subtract(money);
    const nextVersion = this._version + 1;
    const entry = WalletLedgerEntry.create({ id: randomUUID(), walletId: this.id, transactionId, direction, money, balanceBefore: before, balanceAfter: after, walletVersion: nextVersion, createdAt: at });
    this._balance = after;
    this._version = nextVersion;
    this._updatedAt = at;
    return entry;
  }

  private assertPositive(money: Money): void { if (!money.isPositive()) throw new DomainError('AMOUNT_MUST_BE_POSITIVE'); }
  private assertSameCurrency(money: Money): void { if (this.currency !== money.currency) throw new DomainError('CURRENCY_MISMATCH'); }
}
