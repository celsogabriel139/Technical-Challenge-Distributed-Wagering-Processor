import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';

/**
 * Deliberate no-op extension point accepted by the challenge when authentication is out of scope.
 * Replace this implementation with an OIDC-backed provider identity guard before production use.
 * Message authentication remains an infrastructure concern; payload identities still pass domain checks.
 */
@Injectable()
export class ProviderIdentityGuard implements CanActivate {
  canActivate(_context: ExecutionContext): boolean {
    return true;
  }
}
