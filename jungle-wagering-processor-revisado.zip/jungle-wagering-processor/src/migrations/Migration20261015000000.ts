import { Migration } from '@mikro-orm/migrations';

/** Initial schema. Financial correctness is guarded by constraints and deferred triggers in PostgreSQL. */
export class Migration20261015000000 extends Migration {
  async up(): Promise<void> {
    this.addSql(`CREATE TABLE wallets (
      id uuid PRIMARY KEY,
      player_id uuid NOT NULL,
      currency varchar(3) NOT NULL CHECK (currency ~ '^[A-Z]{3}$'),
      balance numeric(20,2) NOT NULL DEFAULT 0 CHECK (balance >= 0),
      version integer NOT NULL DEFAULT 1 CHECK (version >= 1),
      created_at timestamptz NOT NULL,
      updated_at timestamptz NOT NULL,
      CONSTRAINT wallets_player_id_currency_unique UNIQUE (player_id, currency),
      CONSTRAINT wallets_id_currency_unique UNIQUE (id, currency),
      CONSTRAINT wallets_id_player_currency_unique UNIQUE (id, player_id, currency)
    );`);

    this.addSql(`CREATE TABLE wager_transactions (
      id uuid PRIMARY KEY,
      provider_id varchar(255) NOT NULL,
      external_transaction_id varchar(255) NOT NULL,
      idempotency_key varchar(255) NOT NULL,
      payload_hash varchar(64) NOT NULL CHECK (payload_hash ~ '^[a-f0-9]{64}$'),
      wallet_id uuid NOT NULL REFERENCES wallets(id),
      player_id uuid NOT NULL,
      round_id varchar(255) NOT NULL,
      game_id varchar(255) NOT NULL,
      kind varchar(32) NOT NULL CHECK (kind IN ('OPENING','BET','WIN','LOSS','REFUND','ROLLBACK')),
      amount numeric(20,2) NOT NULL CHECK (amount > 0),
      currency varchar(3) NOT NULL CHECK (currency ~ '^[A-Z]{3}$'),
      reference_external_transaction_id varchar(255) NULL,
      reference_transaction_id uuid NULL REFERENCES wager_transactions(id),
      status varchar(32) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','PENDING_REFERENCE','PROCESSED','REJECTED','FAILED')),
      failure_code varchar(100) NULL,
      original_response jsonb NULL,
      created_at timestamptz NOT NULL,
      processed_at timestamptz NULL,
      reference_attempts integer NOT NULL DEFAULT 0 CHECK (reference_attempts >= 0),
      next_reference_attempt_at timestamptz NULL,
      CONSTRAINT wager_transactions_idempotency_key_unique UNIQUE (idempotency_key),
      CONSTRAINT wager_transactions_provider_external_unique UNIQUE (provider_id, external_transaction_id),
      CONSTRAINT wager_transactions_id_wallet_currency_unique UNIQUE (id, wallet_id, currency),
      CONSTRAINT wager_transactions_wallet_player_currency_fk FOREIGN KEY (wallet_id, player_id, currency)
        REFERENCES wallets(id, player_id, currency),
      CONSTRAINT wager_transactions_references_ck CHECK (
        (kind IN ('REFUND','ROLLBACK') AND reference_external_transaction_id IS NOT NULL)
        OR kind = 'WIN'
        OR (kind NOT IN ('REFUND','ROLLBACK','WIN') AND reference_external_transaction_id IS NULL)
      ),
      CONSTRAINT wager_transactions_opening_internal_ck CHECK (kind <> 'OPENING' OR provider_id = 'internal'),
      CONSTRAINT wager_transactions_terminal_processed_at_ck CHECK (
        (status IN ('PROCESSED','REJECTED','FAILED') AND processed_at IS NOT NULL)
        OR (status IN ('PENDING','PENDING_REFERENCE') AND processed_at IS NULL)
      ),
      CONSTRAINT wager_transactions_pending_reference_ck CHECK (
        status <> 'PENDING_REFERENCE'
        OR (next_reference_attempt_at IS NOT NULL AND reference_external_transaction_id IS NOT NULL AND kind IN ('WIN','REFUND','ROLLBACK'))
      ),
      CONSTRAINT wager_transactions_processed_reversal_reference_ck CHECK (
        status <> 'PROCESSED' OR kind NOT IN ('REFUND','ROLLBACK') OR reference_transaction_id IS NOT NULL
      ),
      CONSTRAINT wager_transactions_processed_win_reference_ck CHECK (
        status <> 'PROCESSED' OR kind <> 'WIN' OR reference_external_transaction_id IS NULL OR reference_transaction_id IS NOT NULL
      )
    );`);
    this.addSql(`CREATE INDEX wager_transactions_status_created_at_index ON wager_transactions(status, created_at);`);
    this.addSql(`CREATE INDEX wager_transactions_reference_lookup_index ON wager_transactions(provider_id, reference_external_transaction_id);`);
    this.addSql(`CREATE UNIQUE INDEX wager_transactions_processed_reversal_unique
      ON wager_transactions(reference_transaction_id, kind)
      WHERE status = 'PROCESSED' AND kind IN ('REFUND','ROLLBACK');`);

    this.addSql(`CREATE TABLE wallet_ledger_entries (
      id uuid PRIMARY KEY,
      wallet_id uuid NOT NULL REFERENCES wallets(id),
      transaction_id uuid NOT NULL REFERENCES wager_transactions(id),
      direction varchar(16) NOT NULL CHECK (direction IN ('DEBIT','CREDIT')),
      amount numeric(20,2) NOT NULL CHECK (amount > 0),
      balance_before numeric(20,2) NOT NULL CHECK (balance_before >= 0),
      balance_after numeric(20,2) NOT NULL CHECK (balance_after >= 0),
      currency varchar(3) NOT NULL CHECK (currency ~ '^[A-Z]{3}$'),
      wallet_version integer NOT NULL CHECK (wallet_version >= 1),
      created_at timestamptz NOT NULL,
      CONSTRAINT ledger_wallet_transaction_unique UNIQUE (wallet_id, transaction_id),
      CONSTRAINT ledger_transaction_unique UNIQUE (transaction_id),
      CONSTRAINT ledger_wallet_version_unique UNIQUE (wallet_id, wallet_version),
      CONSTRAINT ledger_wallet_currency_fk FOREIGN KEY (wallet_id, currency) REFERENCES wallets(id, currency),
      CONSTRAINT ledger_transaction_wallet_currency_fk FOREIGN KEY (transaction_id, wallet_id, currency)
        REFERENCES wager_transactions(id, wallet_id, currency),
      CONSTRAINT ledger_arithmetic_ck CHECK (
        (direction = 'CREDIT' AND balance_before + amount = balance_after)
        OR (direction = 'DEBIT' AND balance_before - amount = balance_after)
      )
    );`);
    this.addSql(`CREATE INDEX wallet_ledger_entries_wallet_created_index ON wallet_ledger_entries(wallet_id, created_at DESC, id DESC);`);

    this.addSql(`CREATE TABLE inbox_messages (
      id uuid PRIMARY KEY,
      consumer_name varchar(255) NOT NULL,
      message_id varchar(255) NOT NULL,
      payload_hash varchar(64) NOT NULL CHECK (payload_hash ~ '^[a-f0-9]{64}$'),
      received_at timestamptz NOT NULL,
      processed_at timestamptz NULL,
      CONSTRAINT inbox_messages_consumer_message_unique UNIQUE (consumer_name, message_id)
    );`);

    this.addSql(`CREATE TABLE outbox_messages (
      id uuid PRIMARY KEY,
      aggregate_id varchar(255) NOT NULL,
      event_type varchar(255) NOT NULL,
      payload jsonb NOT NULL,
      created_at timestamptz NOT NULL,
      published_at timestamptz NULL,
      next_attempt_at timestamptz NULL,
      attempts integer NOT NULL DEFAULT 0 CHECK (attempts >= 0),
      last_error text NULL,
      claim_token uuid NULL,
      lease_until timestamptz NULL
    );`);
    this.addSql(`CREATE INDEX outbox_pending_index ON outbox_messages(published_at, next_attempt_at, lease_until, created_at);`);

    // Prevent updates from changing the wallet owner/currency or bypassing balance-version coupling.
    this.addSql(`CREATE FUNCTION enforce_wallet_version() RETURNS trigger AS $$
      BEGIN
        IF NEW.id IS DISTINCT FROM OLD.id OR NEW.player_id IS DISTINCT FROM OLD.player_id OR NEW.currency IS DISTINCT FROM OLD.currency THEN
          RAISE EXCEPTION 'WALLET_IDENTITY_IS_IMMUTABLE' USING ERRCODE = '23514';
        END IF;
        IF NEW.balance IS DISTINCT FROM OLD.balance THEN
          IF NEW.version <> OLD.version + 1 THEN RAISE EXCEPTION 'WALLET_VERSION_MUST_INCREMENT_ON_BALANCE_CHANGE' USING ERRCODE = '23514'; END IF;
        ELSE
          IF NEW.version <> OLD.version THEN RAISE EXCEPTION 'WALLET_VERSION_CANNOT_CHANGE_WITHOUT_BALANCE_CHANGE' USING ERRCODE = '23514'; END IF;
        END IF;
        RETURN NEW;
      END;
    $$ LANGUAGE plpgsql;`);
    this.addSql(`CREATE TRIGGER wallets_version_guard BEFORE UPDATE ON wallets
      FOR EACH ROW EXECUTE FUNCTION enforce_wallet_version();`);

    // Keep persisted idempotency/business identity immutable and make terminal transaction
    // states genuinely terminal at the database boundary, not only in the domain object.
    this.addSql(`CREATE FUNCTION enforce_wager_transaction_invariants() RETURNS trigger AS $$
      BEGIN
        IF TG_OP = 'DELETE' THEN
          RAISE EXCEPTION 'WAGER_TRANSACTION_IS_IMMUTABLE' USING ERRCODE = '55000';
        END IF;
        IF NEW.id IS DISTINCT FROM OLD.id
          OR NEW.provider_id IS DISTINCT FROM OLD.provider_id
          OR NEW.external_transaction_id IS DISTINCT FROM OLD.external_transaction_id
          OR NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key
          OR NEW.payload_hash IS DISTINCT FROM OLD.payload_hash
          OR NEW.wallet_id IS DISTINCT FROM OLD.wallet_id
          OR NEW.player_id IS DISTINCT FROM OLD.player_id
          OR NEW.round_id IS DISTINCT FROM OLD.round_id
          OR NEW.game_id IS DISTINCT FROM OLD.game_id
          OR NEW.kind IS DISTINCT FROM OLD.kind
          OR NEW.amount IS DISTINCT FROM OLD.amount
          OR NEW.currency IS DISTINCT FROM OLD.currency
          OR NEW.reference_external_transaction_id IS DISTINCT FROM OLD.reference_external_transaction_id
          OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
          RAISE EXCEPTION 'WAGER_TRANSACTION_IDENTITY_IS_IMMUTABLE' USING ERRCODE = '55000';
        END IF;
        IF OLD.status IN ('PROCESSED','REJECTED','FAILED') AND (
          NEW.status IS DISTINCT FROM OLD.status
          OR NEW.reference_transaction_id IS DISTINCT FROM OLD.reference_transaction_id
          OR NEW.failure_code IS DISTINCT FROM OLD.failure_code
          OR NEW.original_response IS DISTINCT FROM OLD.original_response
          OR NEW.processed_at IS DISTINCT FROM OLD.processed_at
          OR NEW.reference_attempts IS DISTINCT FROM OLD.reference_attempts
          OR NEW.next_reference_attempt_at IS DISTINCT FROM OLD.next_reference_attempt_at
        ) THEN
          RAISE EXCEPTION 'WAGER_TRANSACTION_TERMINAL_IS_IMMUTABLE' USING ERRCODE = '55000';
        END IF;
        RETURN NEW;
      END;
    $$ LANGUAGE plpgsql;`);
    this.addSql(`CREATE TRIGGER wager_transactions_guard BEFORE UPDATE OR DELETE ON wager_transactions
      FOR EACH ROW EXECUTE FUNCTION enforce_wager_transaction_invariants();`);
    this.addSql(`CREATE FUNCTION prevent_wager_transaction_truncate() RETURNS trigger AS $$
      BEGIN RAISE EXCEPTION 'WAGER_TRANSACTIONS_CANNOT_BE_TRUNCATED' USING ERRCODE = '55000'; RETURN NULL; END;
    $$ LANGUAGE plpgsql;`);
    this.addSql(`CREATE TRIGGER wager_transactions_no_truncate BEFORE TRUNCATE ON wager_transactions
      FOR EACH STATEMENT EXECUTE FUNCTION prevent_wager_transaction_truncate();`);

    // Prevent any direct mutation/deletion of the audit ledger, including from ad-hoc SQL.
    this.addSql(`CREATE FUNCTION prevent_ledger_mutation() RETURNS trigger AS $$
      BEGIN RAISE EXCEPTION 'LEDGER_IS_IMMUTABLE' USING ERRCODE = '55000'; RETURN NULL; END;
    $$ LANGUAGE plpgsql;`);
    this.addSql(`CREATE TRIGGER wallet_ledger_immutable BEFORE UPDATE OR DELETE ON wallet_ledger_entries
      FOR EACH ROW EXECUTE FUNCTION prevent_ledger_mutation();`);
    this.addSql(`CREATE TRIGGER wallet_ledger_no_truncate BEFORE TRUNCATE ON wallet_ledger_entries
      FOR EACH STATEMENT EXECUTE FUNCTION prevent_ledger_mutation();`);

    // Deferred validation lets a wallet update and its matching ledger row commit atomically.
    this.addSql(`CREATE FUNCTION assert_wallet_ledger_consistency() RETURNS trigger AS $$
      DECLARE wid uuid; stored numeric(20,2); ledger_sum numeric(20,2); latest_after numeric(20,2); latest_version integer; bad_chain integer;
      BEGIN
        IF TG_TABLE_NAME = 'wallets' THEN wid := NEW.id; ELSE wid := NEW.wallet_id; END IF;
        SELECT balance, version INTO stored, latest_version FROM wallets WHERE id = wid;
        IF NOT FOUND THEN RETURN NULL; END IF;
        SELECT COALESCE(SUM(CASE WHEN direction = 'CREDIT' THEN amount ELSE -amount END), 0)::numeric(20,2),
               (array_agg(balance_after ORDER BY wallet_version DESC))[1],
               MAX(wallet_version)
          INTO ledger_sum, latest_after, latest_version
          FROM wallet_ledger_entries WHERE wallet_id = wid;
        IF stored <> ledger_sum THEN RAISE EXCEPTION 'WALLET_LEDGER_BALANCE_MISMATCH' USING ERRCODE = '23514'; END IF;
        IF latest_after IS NOT NULL AND latest_after <> stored THEN RAISE EXCEPTION 'WALLET_LEDGER_SNAPSHOT_MISMATCH' USING ERRCODE = '23514'; END IF;
        IF latest_version IS NOT NULL AND latest_version <> (SELECT version FROM wallets WHERE id = wid) THEN
          RAISE EXCEPTION 'WALLET_LEDGER_VERSION_MISMATCH' USING ERRCODE = '23514';
        END IF;
        SELECT COUNT(*) INTO bad_chain FROM (
          SELECT balance_before, ROW_NUMBER() OVER (ORDER BY wallet_version) AS rn,
                 LAG(balance_after) OVER (ORDER BY wallet_version) AS previous_after
          FROM wallet_ledger_entries WHERE wallet_id = wid
        ) chain
        WHERE (rn = 1 AND balance_before <> 0) OR (rn > 1 AND balance_before IS DISTINCT FROM previous_after);
        IF bad_chain > 0 THEN RAISE EXCEPTION 'WALLET_LEDGER_CHAIN_MISMATCH' USING ERRCODE = '23514'; END IF;
        RETURN NULL;
      END;
    $$ LANGUAGE plpgsql;`);
    this.addSql(`CREATE CONSTRAINT TRIGGER wallets_ledger_consistency
      AFTER INSERT OR UPDATE OF balance ON wallets DEFERRABLE INITIALLY DEFERRED
      FOR EACH ROW EXECUTE FUNCTION assert_wallet_ledger_consistency();`);
    this.addSql(`CREATE CONSTRAINT TRIGGER ledger_wallet_consistency
      AFTER INSERT ON wallet_ledger_entries DEFERRABLE INITIALLY DEFERRED
      FOR EACH ROW EXECUTE FUNCTION assert_wallet_ledger_consistency();`);
  }

  async down(): Promise<void> {
    this.addSql('DROP TRIGGER IF EXISTS wager_transactions_no_truncate ON wager_transactions;');
    this.addSql('DROP FUNCTION IF EXISTS prevent_wager_transaction_truncate();');
    this.addSql('DROP TRIGGER IF EXISTS wager_transactions_guard ON wager_transactions;');
    this.addSql('DROP FUNCTION IF EXISTS enforce_wager_transaction_invariants();');
    this.addSql('DROP TRIGGER IF EXISTS ledger_wallet_consistency ON wallet_ledger_entries;');
    this.addSql('DROP TRIGGER IF EXISTS wallets_ledger_consistency ON wallets;');
    this.addSql('DROP FUNCTION IF EXISTS assert_wallet_ledger_consistency();');
    this.addSql('DROP TRIGGER IF EXISTS wallets_version_guard ON wallets;');
    this.addSql('DROP FUNCTION IF EXISTS enforce_wallet_version();');
    this.addSql('DROP TRIGGER IF EXISTS wallet_ledger_no_truncate ON wallet_ledger_entries;');
    this.addSql('DROP TRIGGER IF EXISTS wallet_ledger_immutable ON wallet_ledger_entries;');
    this.addSql('DROP FUNCTION IF EXISTS prevent_ledger_mutation();');
    this.addSql('DROP TABLE IF EXISTS outbox_messages CASCADE;');
    this.addSql('DROP TABLE IF EXISTS inbox_messages CASCADE;');
    this.addSql('DROP TABLE IF EXISTS wallet_ledger_entries CASCADE;');
    this.addSql('DROP TABLE IF EXISTS wager_transactions CASCADE;');
    this.addSql('DROP TABLE IF EXISTS wallets CASCADE;');
  }
}
