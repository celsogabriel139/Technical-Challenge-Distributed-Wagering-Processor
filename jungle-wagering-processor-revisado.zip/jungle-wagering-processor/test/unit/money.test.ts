import { describe, expect, test } from 'bun:test';
import { Money } from '../../src/domain/money';

const brl = (amount: string) => Money.from({ amount, currency: 'BRL' });

describe('Money', () => {
  test('uses exact Decimal arithmetic and fixed two-digit scale', () => {
    expect(brl('0.10').add(brl('0.20')).toString()).toBe('0.30');
    expect(brl('5.00').subtract(brl('3.25')).toJSON()).toEqual({ amount: '1.75', currency: 'BRL' });
    expect(brl('0.01').add(brl('0.02')).toString()).toBe('0.03');
  });

  test('supports signed internal arithmetic without allowing negative input', () => {
    expect(brl('1.00').negate().toString()).toBe('-1.00');
    expect(brl('1.00').subtract(brl('2.00')).toString()).toBe('-1.00');
    expect(() => Money.from({ amount: '-1.00', currency: 'BRL' })).toThrow('INVALID_MONEY_FORMAT');
  });

  test('rejects malformed scale, scientific notation, empty, leading zero and oversized amounts', () => {
    for (const amount of ['', '1', '1.0', '1.001', '1e3', 'NaN', 'Infinity', '-1.00', '01.00', '1000000000000000000.00']) {
      expect(() => Money.from({ amount, currency: 'BRL' })).toThrow();
    }
  });

  test('rejects invalid currency code and currency mismatch', () => {
    expect(() => Money.from({ amount: '1.00', currency: 'brl' })).toThrow('INVALID_CURRENCY');
    expect(() => Money.from({ amount: '1.00', currency: 'ZZZ' })).toThrow('INVALID_CURRENCY');
    expect(() => brl('1.00').add(Money.from({ amount: '1.00', currency: 'USD' }))).toThrow('CURRENCY_MISMATCH');
  });

  test('keeps exact cents near the maximum supported amount', () => {
    expect(brl('999999999999999999.99').subtract(brl('999999999999999999.98')).toString()).toBe('0.01');
  });

  test('rejects overflow from arithmetic', () => {
    expect(() => brl('999999999999999999.99').add(brl('0.01'))).toThrow('MONEY_OVERFLOW');
  });
});
