# Architecture and trade-offs

## Components

- **Domain:** immutable `Money`, `Wallet`, `WalletLedgerEntry`, `WagerTransaction`, inbox/outbox value objects and concrete versioned integration events.
- **Application:** NestJS controllers plus `WalletService` / `WageringService`. HTTP and SQS call the same financial use case.
- **Persistence:** MikroORM Unit of Work and PostgreSQL `numeric(20,2)`, migration-managed constraints and triggers.
- **Messaging:** FIFO command queue, durable transactional inbox, transactional outbox publisher with `FOR UPDATE SKIP LOCKED` claims/leases, retry worker for out-of-order references, and DLQ.
- **Observability:** JSON operational logs, liveness/readiness, Prometheus counters/histogram/gauge. API metrics are exposed at `/metrics`; each worker exports its own `/metrics` on an internal port so worker-only counters remain scrapeable.

## Money representation

Amounts are fixed-scale decimal strings at contract boundaries and PostgreSQL `numeric(20,2)` in storage. `decimal.js` performs exact financial arithmetic. No JS `number` is used as a monetary representation. The amount contract rejects scientific notation, negative values, invalid scale, invalid currency codes and values beyond the database precision.

## Wallet consistency and concurrency

The concurrency aggregate is one wallet row. Every balance-changing use case locks its wallet with `SELECT ... FOR UPDATE` inside the same SQL transaction. Thus a hot wallet serializes while different wallets can progress independently. PostgreSQL is the final arbiter: it enforces unique player/currency wallets, transaction and idempotency identities, one ledger row per wager, non-negative balances, arithmetic and wallet/transaction/currency relationships. A `BEFORE UPDATE` trigger couples balance changes to exactly one version increment; deferred constraint triggers verify at commit that the materialized balance matches ledger reconstruction and snapshots form a valid chain. The ledger rejects row updates/deletes and table truncation. Transaction identity and idempotency fields are database-immutable too; terminal transaction status/result cannot be rewritten or deleted, including by direct SQL.

Initial positive balance creates an internal `OPENING` transaction and a credit ledger entry in the same transaction as wallet creation. A zero-balance wallet has no artificial movement. The version starts at 1 and only advances on balance movements.

## Idempotency and payload hash

`Idempotency-Key` is stored with SHA-256 of a sorted/canonical business payload. Transport metadata and the header itself are not part of that payload hash. Same key + same payload returns the stored response; same key with changed business content is a `409` conflict. `(providerId, externalTransactionId)` is another persistent unique identity. Uniqueness violations from concurrent database transactions are recovered by loading the winning result when possible.

## Atomic processing

The transaction persisted for a wager, status/result, wallet version+balance, optional ledger entry, queue inbox receipt and outbox event share one PostgreSQL transaction. Events are only published after commit, by the outbox publisher. Each publisher claims rows using `FOR UPDATE SKIP LOCKED`, a UUID claim token and a lease, then sends outside the database transaction. A crash between SQS acceptance and `published_at` update may produce a duplicate event; event consumers must deduplicate by `eventId`. This is at-least-once, not exactly-once, delivery.

Queue inbox uniqueness is `(consumer_name, message_id)`. The SQS worker acknowledges only after the transaction commits. Business rejections are terminal and acknowledged; permanent invalid messages go to the DLQ; transient failures use exponential visibility delay and eventually SQS redrive. SIGTERM stops new receives and allows the current batch to finish before shutdown.

## Out-of-order references

`WIN` may include an optional `BET` reference; when present, the reference must be processed and match provider, player, wallet, currency and round, but the payout need not equal the stake. `REFUND` requires a processed `BET`; `ROLLBACK` requires a processed `BET`, `WIN` or `REFUND`. Reversals validate provider, player, wallet, currency, round and exact amount. A missing reference is saved as `PENDING_REFERENCE`, emits a pending event and schedules exponential retries. References that themselves remain pending are retried too; a bounded-attempt terminal rejection uses `REFERENCE_NOT_FOUND` or `REFERENCE_NOT_PROCESSED`. Duplicate reversals of the same type and reference are rejected; the database has a partial unique index as a final guard. A reversal that would produce a negative wallet is rejected as `REVERSAL_BALANCE_NEGATIVE`, distinct from an unaffordable wager (`INSUFFICIENT_FUNDS`).

## Reconciliation and observability

Reconciliation does not repair silently: it returns stored, reconstructed and difference balances and emits a structured warning/counter on mismatch. Metrics include status totals, duplicate detection, retries, DLQ, database lock conflicts, reconciliation errors, processing latency and outbox lag. Logs avoid amount/payload dumps and include correlation/message/transaction/provider/wallet identifiers where available.

## Authentication decision

Authentication is intentionally not implemented because the challenge explicitly assigns it zero evaluation points and permits opting out. `ProviderIdentityGuard` is the explicit no-op extension point on provider-facing API controllers. Replace it with an OIDC guard backed by an external IdP (e.g. Keycloak or Zitadel) before production. Health endpoints remain public. Queue payload identities are still checked against wallet/player/currency and transaction-domain rules.

## Remaining production considerations

This is challenge-scoped code, not a certified payment platform. Production rollout should add OIDC integration, retention/PII policies, rate limits, circuit breakers and alerts, SQS IAM policies and secrets management, event-consumer idempotency, load testing, backup/restore drills, and operational dashboards. Exactly-once delivery across PostgreSQL and SQS is not claimed.
