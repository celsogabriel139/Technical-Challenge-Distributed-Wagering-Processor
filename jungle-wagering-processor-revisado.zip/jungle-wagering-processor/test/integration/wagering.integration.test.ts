import 'reflect-metadata';
import { afterAll, beforeAll, describe, expect, test } from 'bun:test';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { MikroORM } from '@mikro-orm/postgresql';
import ormConfig from '../../mikro-orm.config';
import { MoneyProps } from '../../src/domain/money';
import { MetricsService } from '../../src/modules/metrics/metrics.service';
import { WageringService, WagerInput } from '../../src/modules/wagering/wagering.service';
import { WalletService } from '../../src/modules/wallets/wallet.service';
import { WagerTransactionEntity } from '../../src/modules/persistence/entities/wager-transaction.entity';
import { LedgerEntryEntity } from '../../src/modules/persistence/entities/ledger-entry.entity';
import { InboxMessageEntity } from '../../src/modules/persistence/entities/inbox-message.entity';
import { OutboxMessageEntity } from '../../src/modules/persistence/entities/outbox-message.entity';
import { QueueService } from '../../src/modules/messaging/queue.service';
import { OutboxPublisherService } from '../../src/modules/messaging/outbox-publisher.service';

const enabled = process.env.RUN_INTEGRATION_TESTS === '1';
const suite = enabled ? describe : describe.skip;
const helperPath = fileURLToPath(new URL('../helpers/child-use-case.ts', import.meta.url));
let orm: MikroORM;
let metrics: MetricsService;
let queue: QueueService;

function makeWageringService() { return new WageringService(orm.em.fork({ clear: true }), metrics); }
function makeWalletService() { return new WalletService(orm.em.fork({ clear: true }), metrics); }
function money(amount: string, currency = 'BRL'): MoneyProps { return { amount, currency }; }
async function createWallet(initialBalance: string) {
  const playerId = randomUUID();
  return { playerId, wallet: await makeWalletService().create({ playerId, initialBalance: money(initialBalance) }) };
}
function wager(walletId: string, playerId: string, externalTransactionId = randomUUID(), amount = '10.00', kind: WagerInput['kind'] = 'BET', referenceExternalTransactionId?: string): WagerInput {
  return { providerId: 'integration-provider', externalTransactionId, playerId, walletId, roundId: 'round-integration', gameId: 'game-integration', kind, money: money(amount), ...(referenceExternalTransactionId ? { referenceExternalTransactionId } : {}) };
}
async function spawnUseCase(args: unknown): Promise<any> {
  return await new Promise((resolve, reject) => {
    const child = spawn(process.env.BUN ?? 'bun', [helperPath, JSON.stringify(args)], { env: { ...process.env, NODE_ENV: 'test' }, stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = ''; let stderr = '';
    child.stdout.setEncoding('utf8').on('data', (data: string) => { stdout += data; });
    child.stderr.setEncoding('utf8').on('data', (data: string) => { stderr += data; });
    child.on('error', reject);
    child.on('close', code => {
      const marker = stdout.split('\n').find(line => line.startsWith('RESULT_JSON:'));
      if (code !== 0 || !marker) return reject(new Error(`child failed (${code}): ${stderr}\n${stdout}`));
      try { resolve(JSON.parse(marker.slice('RESULT_JSON:'.length))); }
      catch (error) { reject(error); }
    });
  });
}

suite('Distributed wagering processor — real PostgreSQL + LocalStack', () => {
  beforeAll(async () => {
    orm = await MikroORM.init(ormConfig);
    await orm.getMigrator().up();
    metrics = new MetricsService();
    queue = new QueueService();
    if (!await queue.checkReady()) throw new Error('Integration tests require PostgreSQL and the four SQS queues in LocalStack. Run `bun run init:sqs` first.');
  }, 60_000);

  afterAll(async () => { if (orm) await orm.close(true); if (queue) queue.client.destroy(); });

  test('the same wager submitted 50 times in parallel produces one debit and durable replays', async () => {
    const { playerId, wallet } = await createWallet('100.00');
    const input = wager(wallet.id, playerId, randomUUID(), '25.00');
    const key = `${input.providerId}:${input.externalTransactionId}`;
    const results = await Promise.all(Array.from({ length: 50 }, () => makeWageringService().submit(input, key)));
    expect(results.filter(result => !result.idempotentReplay)).toHaveLength(1);
    expect(results.every(result => result.transactionId === results[0].transactionId)).toBe(true);
    const checkEm = orm.em.fork({ clear: true });
    const transactions = await checkEm.find(WagerTransactionEntity, { idempotencyKey: key });
    const entries = await checkEm.find(LedgerEntryEntity, { transactionId: results[0].transactionId });
    expect(transactions).toHaveLength(1);
    expect(entries).toHaveLength(1);
    expect((await makeWalletService().get(wallet.id)).balance.amount).toBe('75.00');
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);
  }, 60_000);

  test('two concurrent 80.00 bets against 100.00 produce one debit and one insufficient-funds rejection', async () => {
    const { playerId, wallet } = await createWallet('100.00');
    const first = wager(wallet.id, playerId, randomUUID(), '80.00');
    const second = wager(wallet.id, playerId, randomUUID(), '80.00');
    const results = await Promise.all([
      makeWageringService().submit(first, `key:${first.externalTransactionId}`),
      makeWageringService().submit(second, `key:${second.externalTransactionId}`),
    ]);
    expect(results.filter(result => result.status === 'PROCESSED')).toHaveLength(1);
    expect(results.filter(result => result.status === 'REJECTED' && result.failureCode === 'INSUFFICIENT_FUNDS')).toHaveLength(1);
    expect((await makeWalletService().get(wallet.id)).balance.amount).toBe('20.00');
    const checkEm = orm.em.fork({ clear: true });
    expect(await checkEm.count(LedgerEntryEntity, { walletId: wallet.id, direction: 'DEBIT' })).toBe(1);
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);
  });

  test('currency mismatch is rejected and LOSS is processed without a ledger movement', async () => {
    const { playerId, wallet } = await createWallet('40.00');
    const wrongCurrency = wager(wallet.id, playerId, randomUUID(), '5.00');
    wrongCurrency.money = money('5.00', 'USD');
    await expect(makeWageringService().submit(wrongCurrency, `currency:${wrongCurrency.externalTransactionId}`)).rejects.toThrow('WALLET_CURRENCY_MISMATCH');

    const loss = wager(wallet.id, playerId, randomUUID(), '5.00', 'LOSS');
    const result = await makeWageringService().submit(loss, `loss:${loss.externalTransactionId}`);
    expect(result.status).toBe('PROCESSED');
    const checkEm = orm.em.fork({ clear: true });
    expect(await checkEm.count(LedgerEntryEntity, { transactionId: result.transactionId })).toBe(0);
    expect((await makeWalletService().get(wallet.id)).balance.amount).toBe('40.00');
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);
  });

  test('atomicity: an outbox insert failure rolls back wallet, transaction and ledger together', async () => {
    const { playerId, wallet } = await createWallet('100.00');
    const input = wager(wallet.id, playerId, randomUUID(), '12.00');
    const key = `atomic:${input.externalTransactionId}`;
    const connection = orm.em.fork({ clear: true }).getConnection();
    await connection.execute('DROP TRIGGER IF EXISTS test_fail_outbox_before_insert ON outbox_messages');
    await connection.execute('DROP FUNCTION IF EXISTS fail_test_outbox_insert()');
    await connection.execute(`CREATE FUNCTION fail_test_outbox_insert() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'TEST_OUTBOX_FAIL'; END; $$`);
    await connection.execute('CREATE TRIGGER test_fail_outbox_before_insert BEFORE INSERT ON outbox_messages FOR EACH ROW EXECUTE FUNCTION fail_test_outbox_insert()');
    try {
      await expect(makeWageringService().submit(input, key)).rejects.toThrow('TEST_OUTBOX_FAIL');
    } finally {
      await connection.execute('DROP TRIGGER IF EXISTS test_fail_outbox_before_insert ON outbox_messages');
      await connection.execute('DROP FUNCTION IF EXISTS fail_test_outbox_insert()');
    }
    const checkEm = orm.em.fork({ clear: true });
    expect(await checkEm.findOne(WagerTransactionEntity, { providerId: input.providerId, externalTransactionId: input.externalTransactionId })).toBeNull();
    expect(await checkEm.count(LedgerEntryEntity, { walletId: wallet.id })).toBe(1); // only the opening credit remains
    expect((await makeWalletService().get(wallet.id)).balance.amount).toBe('100.00');
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);
  }, 60_000);

  test('SQS inbox, wallet, ledger and outbox roll back together on SQL failure', async () => {
    const { playerId, wallet } = await createWallet('100.00');
    const input = wager(wallet.id, playerId, randomUUID(), '12.00');
    const messageId = randomUUID();
    const envelope = {
      messageId,
      type: 'WagerTransactionRequested',
      occurredAt: new Date().toISOString(),
      data: { ...input, idempotencyKey: `atomic-queue:${input.externalTransactionId}` },
    };
    const connection = orm.em.fork({ clear: true }).getConnection();
    await connection.execute('DROP TRIGGER IF EXISTS test_fail_queue_outbox_before_insert ON outbox_messages');
    await connection.execute('DROP FUNCTION IF EXISTS fail_test_queue_outbox_insert()');
    await connection.execute(`CREATE FUNCTION fail_test_queue_outbox_insert() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'TEST_QUEUE_OUTBOX_FAIL'; END; $$`);
    await connection.execute('CREATE TRIGGER test_fail_queue_outbox_before_insert BEFORE INSERT ON outbox_messages FOR EACH ROW EXECUTE FUNCTION fail_test_queue_outbox_insert()');
    try {
      await expect(makeWageringService().processQueueMessage('integration-atomic-queue', messageId, envelope)).rejects.toThrow('TEST_QUEUE_OUTBOX_FAIL');
    } finally {
      await connection.execute('DROP TRIGGER IF EXISTS test_fail_queue_outbox_before_insert ON outbox_messages');
      await connection.execute('DROP FUNCTION IF EXISTS fail_test_queue_outbox_insert()');
    }

    const checkEm = orm.em.fork({ clear: true });
    expect(await checkEm.count(InboxMessageEntity, { consumerName: 'integration-atomic-queue', messageId })).toBe(0);
    expect(await checkEm.findOne(WagerTransactionEntity, { providerId: input.providerId, externalTransactionId: input.externalTransactionId })).toBeNull();
    expect(await checkEm.count(LedgerEntryEntity, { walletId: wallet.id })).toBe(1); // only OPENING
    expect((await makeWalletService().get(wallet.id)).balance.amount).toBe('100.00');

    const retry = await makeWageringService().processQueueMessage('integration-atomic-queue', messageId, envelope);
    expect(retry.duplicate).toBe(false);
    expect(retry.result?.status).toBe('PROCESSED');
    expect(await checkEm.count(InboxMessageEntity, { consumerName: 'integration-atomic-queue', messageId })).toBe(1);
    expect((await makeWalletService().get(wallet.id)).balance.amount).toBe('88.00');
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);
  }, 60_000);

  test('wallets are independent and process concurrently', async () => {
    const left = await createWallet('20.00');
    const right = await createWallet('20.00');
    const a = wager(left.wallet.id, left.playerId, randomUUID(), '15.00');
    const b = wager(right.wallet.id, right.playerId, randomUUID(), '17.00');
    const [ra, rb] = await Promise.all([
      makeWageringService().submit(a, `key:${a.externalTransactionId}`),
      makeWageringService().submit(b, `key:${b.externalTransactionId}`),
    ]);
    expect(ra.status).toBe('PROCESSED'); expect(rb.status).toBe('PROCESSED');
    expect((await makeWalletService().get(left.wallet.id)).balance.amount).toBe('5.00');
    expect((await makeWalletService().get(right.wallet.id)).balance.amount).toBe('3.00');
    expect((await makeWalletService().reconcile(left.wallet.id)).consistent).toBe(true);
    expect((await makeWalletService().reconcile(right.wallet.id)).consistent).toBe(true);
  });

  test('three independent OS processes contend safely for one wallet', async () => {
    const { playerId, wallet } = await createWallet('100.00');
    const inputs = [randomUUID(), randomUUID(), randomUUID()].map(externalTransactionId => {
      const input = wager(wallet.id, playerId, externalTransactionId, '80.00');
      return { action: 'submit', input, key: `process:${externalTransactionId}` };
    });
    const results = await Promise.all(inputs.map(spawnUseCase));
    expect(results.filter(result => result.status === 'PROCESSED')).toHaveLength(1);
    expect(results.filter(result => result.status === 'REJECTED')).toHaveLength(2);
    expect((await makeWalletService().get(wallet.id)).balance.amount).toBe('20.00');
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);
  }, 90_000);

  test('a worker process exits after commit but before ack; real SQS redelivery stays idempotent', async () => {
    const { playerId, wallet } = await createWallet('50.00');
    const input = wager(wallet.id, playerId, randomUUID(), '12.00');
    const messageId = randomUUID();
    const envelope = { messageId, type: 'WagerTransactionRequested', occurredAt: new Date().toISOString(), data: { ...input, idempotencyKey: `queue:${input.externalTransactionId}` } };
    await queue.sendTransactionRequest(envelope, `crash-${messageId}`, messageId);
    const first = await spawnUseCase({ action: 'crash-after-queue-commit', consumerName: 'integration-crash-test', messageId });
    expect(first.committedWithoutAck).toBe(true);
    expect(first.outcome.duplicate).toBe(false);

    let redelivery: { ReceiptHandle?: string; Body?: string } | undefined;
    for (let attempt = 0; attempt < 6 && !redelivery; attempt++) {
      const batch = await queue.receive();
      redelivery = batch.Messages?.find(message => {
        try { return (JSON.parse(message.Body ?? '') as { messageId?: string }).messageId === messageId; } catch { return false; }
      });
      for (const message of batch.Messages ?? []) {
        if (message.ReceiptHandle && message.ReceiptHandle !== redelivery?.ReceiptHandle) await queue.release(message.ReceiptHandle, 30);
      }
    }
    expect(redelivery?.ReceiptHandle).toBeTruthy();
    const second = await makeWageringService().processQueueMessage('integration-crash-test', messageId, JSON.parse(redelivery!.Body!) as unknown);
    expect(second.duplicate).toBe(true);
    await queue.ack(redelivery!.ReceiptHandle!);

    const checkEm = orm.em.fork({ clear: true });
    expect(await checkEm.count(InboxMessageEntity, { consumerName: 'integration-crash-test', messageId })).toBe(1);
    expect(await checkEm.count(LedgerEntryEntity, { transactionId: first.outcome.result.transactionId })).toBe(1);
    expect((await makeWalletService().get(wallet.id)).balance.amount).toBe('38.00');
  }, 90_000);

  test('REFUND arriving before BET is reprocessed and credits exactly once when reference appears', async () => {
    const { playerId, wallet } = await createWallet('100.00');
    const betId = randomUUID();
    const refund = wager(wallet.id, playerId, randomUUID(), '20.00', 'REFUND', betId);
    const pending = await makeWageringService().submit(refund, `refund:${refund.externalTransactionId}`);
    expect(pending.status).toBe('PENDING_REFERENCE');
    const bet = wager(wallet.id, playerId, betId, '20.00', 'BET');
    const betResult = await makeWageringService().submit(bet, `bet:${bet.externalTransactionId}`);
    expect(betResult.status).toBe('PROCESSED');
    const pendingEm = orm.em.fork({ clear: true });
    await pendingEm.nativeUpdate(WagerTransactionEntity, { id: pending.transactionId }, { nextReferenceAttemptAt: new Date(Date.now() - 1000) });
    expect(await makeWageringService().retryPendingReferences()).toBeGreaterThanOrEqual(1);
    expect((await makeWageringService().get(pending.transactionId)).status).toBe('PROCESSED');
    expect((await makeWalletService().get(wallet.id)).balance.amount).toBe('100.00');
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);
  }, 60_000);

  test('a WIN with an optional BET reference waits for it and validates the relationship without equating payout to stake', async () => {
    const { playerId, wallet } = await createWallet('100.00');
    const betExternalId = randomUUID();
    const win = wager(wallet.id, playerId, randomUUID(), '30.00', 'WIN', betExternalId);
    const pending = await makeWageringService().submit(win, `win-ref:${win.externalTransactionId}`);
    expect(pending.status).toBe('PENDING_REFERENCE');

    const bet = wager(wallet.id, playerId, betExternalId, '20.00', 'BET');
    const betResult = await makeWageringService().submit(bet, `bet-ref:${betExternalId}`);
    expect(betResult.status).toBe('PROCESSED');
    await orm.em.fork({ clear: true }).nativeUpdate(WagerTransactionEntity, { id: pending.transactionId }, { nextReferenceAttemptAt: new Date(Date.now() - 1000) });
    await makeWageringService().retryPendingReferences();

    const completed = await orm.em.fork({ clear: true }).findOne(WagerTransactionEntity, { id: pending.transactionId });
    expect(completed?.status).toBe('PROCESSED');
    expect(completed?.referenceTransactionId).toBe(betResult.transactionId);
    expect((await makeWalletService().get(wallet.id)).balance.amount).toBe('110.00');
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);
  }, 60_000);

  test('ROLLBACK arriving before WIN is retried; debit cannot make wallet negative', async () => {
    const { playerId, wallet } = await createWallet('10.00');
    const winId = randomUUID();
    const rollback = wager(wallet.id, playerId, randomUUID(), '30.00', 'ROLLBACK', winId);
    const pending = await makeWageringService().submit(rollback, `rollback:${rollback.externalTransactionId}`);
    expect(pending.status).toBe('PENDING_REFERENCE');
    const win = wager(wallet.id, playerId, winId, '30.00', 'WIN');
    expect((await makeWageringService().submit(win, `win:${winId}`)).status).toBe('PROCESSED');
    const spend = wager(wallet.id, playerId, randomUUID(), '30.00', 'BET');
    expect((await makeWageringService().submit(spend, `spend:${spend.externalTransactionId}`)).status).toBe('PROCESSED');
    await orm.em.fork({ clear: true }).nativeUpdate(WagerTransactionEntity, { id: pending.transactionId }, { nextReferenceAttemptAt: new Date(Date.now() - 1000) });
    await makeWageringService().retryPendingReferences();
    expect((await makeWageringService().get(pending.transactionId)).status).toBe('REJECTED');
    expect((await makeWageringService().get(pending.transactionId) as any).failureCode).toBe('REVERSAL_BALANCE_NEGATIVE');
    expect((await makeWalletService().get(wallet.id)).balance.amount).toBe('10.00');
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);
  }, 60_000);

  test('rejects a reference with the wrong kind immediately even when that reference is pending', async () => {
    const { playerId, wallet } = await createWallet('100.00');
    const pendingWinId = randomUUID();
    const pendingWin = wager(wallet.id, playerId, pendingWinId, '30.00', 'WIN', randomUUID());
    expect((await makeWageringService().submit(pendingWin, `pending-win:${pendingWinId}`)).status).toBe('PENDING_REFERENCE');

    const refund = wager(wallet.id, playerId, randomUUID(), '30.00', 'REFUND', pendingWinId);
    const rejected = await makeWageringService().submit(refund, `wrong-reference-kind:${refund.externalTransactionId}`);
    expect(rejected.status).toBe('REJECTED');
    expect(rejected.failureCode).toBe('INVALID_REFERENCE_KIND');
    expect((await makeWalletService().get(wallet.id)).balance.amount).toBe('100.00');
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);
  });

  test('a different payload under the same idempotency key is a conflict', async () => {
    const { playerId, wallet } = await createWallet('100.00');
    const input = wager(wallet.id, playerId, randomUUID(), '10.00');
    const key = `conflict:${input.externalTransactionId}`;
    await makeWageringService().submit(input, key);
    const changed = { ...input, money: money('11.00') };
    await expect(makeWageringService().submit(changed, key)).rejects.toThrow('IDEMPOTENCY_KEY_PAYLOAD_CONFLICT');
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);
  });

  test('a BET cannot be refunded twice by the same reversal type', async () => {
    const { playerId, wallet } = await createWallet('50.00');
    const betExternalId = randomUUID();
    const bet = wager(wallet.id, playerId, betExternalId, '20.00', 'BET');
    expect((await makeWageringService().submit(bet, `bet:${betExternalId}`)).status).toBe('PROCESSED');
    const refundOne = wager(wallet.id, playerId, randomUUID(), '20.00', 'REFUND', betExternalId);
    expect((await makeWageringService().submit(refundOne, `refund:${refundOne.externalTransactionId}`)).status).toBe('PROCESSED');
    const refundTwo = wager(wallet.id, playerId, randomUUID(), '20.00', 'REFUND', betExternalId);
    const rejected = await makeWageringService().submit(refundTwo, `refund:${refundTwo.externalTransactionId}`);
    expect(rejected.status).toBe('REJECTED');
    expect(rejected.failureCode).toBe('REFERENCE_ALREADY_REVERSED');
    expect((await makeWalletService().get(wallet.id)).balance.amount).toBe('50.00');
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);
  });

  test('wallet version and owner/currency identity are guarded by database triggers/constraints', async () => {
    const { playerId, wallet } = await createWallet('5.00');
    const connection = orm.em.fork({ clear: true }).getConnection();
    await expect(connection.execute('UPDATE wallets SET version = version + 1 WHERE id = ?', [wallet.id])).rejects.toThrow('WALLET_VERSION_CANNOT_CHANGE_WITHOUT_BALANCE_CHANGE');
    await expect(connection.execute('UPDATE wallets SET currency = ? WHERE id = ?', ['USD', wallet.id])).rejects.toThrow('WALLET_IDENTITY_IS_IMMUTABLE');
    await expect(makeWalletService().create({ playerId, initialBalance: money('1.00') })).rejects.toThrow('WALLET_ALREADY_EXISTS');

    const input = wager(wallet.id, playerId, randomUUID(), '1.00', 'BET');
    const processed = await makeWageringService().submit(input, `terminal-guard:${input.externalTransactionId}`);
    expect(processed.status).toBe('PROCESSED');
    await expect(connection.execute('UPDATE wager_transactions SET status = ? WHERE id = ?', ['PENDING', processed.transactionId]))
      .rejects.toThrow('WAGER_TRANSACTION_TERMINAL_IS_IMMUTABLE');
    await expect(connection.execute('DELETE FROM wager_transactions WHERE id = ?', [processed.transactionId]))
      .rejects.toThrow('WAGER_TRANSACTION_IS_IMMUTABLE');
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);
  });

  test('two publishers racing over one outbox record never both claim that row', async () => {
    // Isolated integration-test database: remove stale outbox events to make the one-row race deterministic.
    await orm.em.fork({ clear: true }).getConnection().execute('DELETE FROM outbox_messages');
    const { playerId, wallet } = await createWallet('0.00');
    const loss = wager(wallet.id, playerId, randomUUID(), '1.00', 'LOSS');
    await makeWageringService().submit(loss, `loss:${loss.externalTransactionId}`); // Exactly one event, no balance movement.
    const publisher1 = new OutboxPublisherService(orm.em.fork({ clear: true }), queue, metrics);
    const publisher2 = new OutboxPublisherService(orm.em.fork({ clear: true }), queue, metrics);
    const counts = await Promise.all([publisher1.processBatch(1), publisher2.processBatch(1)]);
    expect(counts.reduce((sum, count) => sum + count, 0)).toBe(1);
    const after = await orm.em.fork({ clear: true }).find(OutboxMessageEntity, {});
    expect(after).toHaveLength(1);
    expect(after.every(row => row.publishedAt instanceof Date)).toBe(true);
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);
  }, 60_000);

  test('outbox schedules transient failures and later publishes the same durable event', async () => {
    await orm.em.fork({ clear: true }).getConnection().execute('DELETE FROM outbox_messages');
    const { playerId, wallet } = await createWallet('0.00');
    const loss = wager(wallet.id, playerId, randomUUID(), '1.00', 'LOSS');
    const submitted = await makeWageringService().submit(loss, `retry-outbox:${loss.externalTransactionId}`);
    const rowEm = orm.em.fork({ clear: true });
    const failingQueue = {
      sendEvent: async () => { throw new Error('INJECTED_TRANSIENT_SQS_FAILURE'); },
    } as unknown as QueueService;
    const failingPublisher = new OutboxPublisherService(rowEm, failingQueue, metrics);
    expect(await failingPublisher.processBatch(1)).toBe(1);

    let row = await rowEm.findOne(OutboxMessageEntity, { aggregateId: submitted.transactionId, eventType: 'WagerTransactionProcessed' });
    expect(row).not.toBeNull();
    expect(row!.attempts).toBe(1);
    expect(row!.publishedAt).toBeUndefined();
    expect(row!.nextAttemptAt).toBeInstanceOf(Date);

    await rowEm.nativeUpdate(OutboxMessageEntity, { id: row!.id }, { nextAttemptAt: new Date(Date.now() - 1000) });
    const realPublisher = new OutboxPublisherService(orm.em.fork({ clear: true }), queue, metrics);
    expect(await realPublisher.processBatch(1)).toBe(1);
    const publishedRow = await orm.em.fork({ clear: true }).findOne(OutboxMessageEntity, { id: row!.id });
    expect(publishedRow!.attempts).toBe(2);
    expect(publishedRow!.publishedAt).toBeInstanceOf(Date);
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);
  }, 60_000);

  test('database enforces ledger immutability', async () => {
    const { playerId, wallet } = await createWallet('5.00');
    const entry = (await orm.em.fork({ clear: true }).findOne(LedgerEntryEntity, { walletId: wallet.id }))!;
    await expect(orm.em.fork({ clear: true }).nativeUpdate(LedgerEntryEntity, { id: entry.id }, { amount: '4.00' })).rejects.toThrow();
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);
  });

  test('a successful ROLLBACK reverses a processed WIN exactly once and preserves ledger reconciliation', async () => {
    const { playerId, wallet } = await createWallet('100.00');
    const betId = randomUUID();
    const bet = wager(wallet.id, playerId, betId, '20.00', 'BET');
    const betResult = await makeWageringService().submit(bet, `rollback-success-bet:${betId}`);
    expect(betResult.status).toBe('PROCESSED');

    const winId = randomUUID();
    const win = wager(wallet.id, playerId, winId, '30.00', 'WIN', betId);
    expect((await makeWageringService().submit(win, `rollback-success-win:${winId}`)).status).toBe('PROCESSED');

    const rollbackId = randomUUID();
    const rollback = wager(wallet.id, playerId, rollbackId, '30.00', 'ROLLBACK', winId);
    const result = await makeWageringService().submit(rollback, `rollback-success:${rollbackId}`);
    expect(result.status).toBe('PROCESSED');
    expect((await makeWageringService().submit(rollback, `rollback-success:${rollbackId}`)).idempotentReplay).toBe(true);
    expect((await makeWalletService().get(wallet.id)).balance.amount).toBe('80.00');

    const entries = await orm.em.fork({ clear: true }).find(LedgerEntryEntity, { walletId: wallet.id }, { orderBy: { walletVersion: 'ASC' } });
    expect(entries.map(entry => entry.direction)).toEqual(['CREDIT', 'DEBIT', 'CREDIT', 'DEBIT']);
    expect(entries.map(entry => entry.balanceAfter)).toEqual(['100.00', '80.00', '110.00', '80.00']);
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);
  }, 60_000);

  test('service database connections can restart without losing the ledger invariant', async () => {
    const { playerId, wallet } = await createWallet('60.00');
    const bet = wager(wallet.id, playerId, randomUUID(), '15.00', 'BET');
    expect((await makeWageringService().submit(bet, `restart:${bet.externalTransactionId}`)).status).toBe('PROCESSED');
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);

    await orm.close(true);
    orm = await MikroORM.init(ormConfig);
    metrics = new MetricsService();

    expect((await makeWalletService().get(wallet.id)).balance.amount).toBe('45.00');
    const transaction = await orm.em.fork({ clear: true }).findOne(WagerTransactionEntity, { externalTransactionId: bet.externalTransactionId });
    expect(transaction?.status).toBe('PROCESSED');
    expect(await orm.em.fork({ clear: true }).count(LedgerEntryEntity, { walletId: wallet.id })).toBe(2); // OPENING + BET
    expect((await makeWalletService().reconcile(wallet.id)).consistent).toBe(true);
  }, 60_000);

  test('DLQ receives a durable permanent-failure envelope', async () => {
    const marker = `dlq-test-${randomUUID()}`;
    await queue.sendToDeadLetterQueue({ marker }, 'TEST_PERMANENT_FAILURE');
    const { SQSClient, ReceiveMessageCommand, DeleteMessageCommand } = await import('@aws-sdk/client-sqs');
    const client = new SQSClient({ region: process.env.AWS_REGION ?? 'us-east-1', endpoint: process.env.SQS_ENDPOINT ?? 'http://localhost:4566', credentials: { accessKeyId: 'test', secretAccessKey: 'test' } });
    const url = process.env.SQS_DLQ_URL!;
    let found: { ReceiptHandle?: string; Body?: string } | undefined;
    for (let attempt = 0; attempt < 6 && !found; attempt++) {
      const result = await client.send(new ReceiveMessageCommand({ QueueUrl: url, MaxNumberOfMessages: 10, WaitTimeSeconds: 2, VisibilityTimeout: 10 }));
      found = result.Messages?.find(message => message.Body?.includes(marker));
    }
    expect(found?.Body).toContain(marker);
    if (found?.ReceiptHandle) await client.send(new DeleteMessageCommand({ QueueUrl: url, ReceiptHandle: found.ReceiptHandle }));
    await client.destroy();
  }, 30_000);
});
