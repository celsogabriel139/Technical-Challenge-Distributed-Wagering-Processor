import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { OutboxPublisherService } from './modules/messaging/outbox-publisher.service';
import { MetricsService } from './modules/metrics/metrics.service';
import { startMetricsServer, stopMetricsServer } from './metrics-server';

async function main() {
  const app = await NestFactory.createApplicationContext(AppModule, { logger: ['error', 'warn', 'log'] });
  const publisher = app.get(OutboxPublisherService);
  const metricsServer = await startMetricsServer(app.get(MetricsService), Number(process.env.METRICS_PORT ?? 3002), 'outbox-worker');
  let stopping = false;
  process.on('SIGTERM', () => { stopping = true; });
  process.on('SIGINT', () => { stopping = true; });
  while (!stopping) {
    try {
      const claimed = await publisher.processBatch(25);
      if (claimed === 0) await new Promise(resolve => setTimeout(resolve, Math.max(100, Number(process.env.OUTBOX_POLL_MS ?? 1000))));
    } catch (error) {
      console.error(JSON.stringify({ level: 'error', message: 'outbox_poll_failed', errorType: error instanceof Error ? error.name : 'UNKNOWN_ERROR' }));
      await new Promise(resolve => setTimeout(resolve, Math.max(250, Number(process.env.OUTBOX_POLL_MS ?? 1000))));
    }
  }
  await app.close();
  await stopMetricsServer(metricsServer);
}

main().catch(error => { console.error(JSON.stringify({ level: 'fatal', message: 'outbox_worker_failed', errorType: error instanceof Error ? error.name : 'UNKNOWN_ERROR' })); process.exitCode = 1; });
