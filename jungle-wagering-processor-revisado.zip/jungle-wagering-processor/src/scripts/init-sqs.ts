import {
  SQSClient, CreateQueueCommand, GetQueueUrlCommand, GetQueueAttributesCommand, SetQueueAttributesCommand,
} from '@aws-sdk/client-sqs';

const endpoint = process.env.SQS_ENDPOINT ?? 'http://localhost:4566';
const client = new SQSClient({
  region: process.env.AWS_REGION ?? 'us-east-1',
  endpoint,
  credentials: { accessKeyId: process.env.AWS_ACCESS_KEY_ID ?? 'test', secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY ?? 'test' },
});

function normalizeQueueUrl(queueUrl: string): string {
  // LocalStack may return localhost or a generated virtual-host URL. Use the endpoint
  // reachable from this process (localhost on host, `localstack` from Compose).
  const parsed = new URL(queueUrl);
  const configuredEndpoint = new URL(endpoint);
  parsed.protocol = configuredEndpoint.protocol;
  parsed.host = configuredEndpoint.host;
  return parsed.toString();
}

async function ensureQueue(name: string, attributes: Record<string, string> = {}): Promise<{ url: string; arn: string }> {
  try {
    await client.send(new CreateQueueCommand({ QueueName: name, Attributes: { FifoQueue: 'true', ContentBasedDeduplication: 'false', ...attributes } }));
  } catch (error) {
    const response = await client.send(new GetQueueUrlCommand({ QueueName: name })).catch(() => { throw error; });
    if (!response.QueueUrl) throw new Error(`Cannot resolve SQS queue ${name}`);
  }
  const rawUrl = (await client.send(new GetQueueUrlCommand({ QueueName: name }))).QueueUrl;
  if (!rawUrl) throw new Error(`Cannot resolve SQS queue ${name}`);
  const url = normalizeQueueUrl(rawUrl);
  const mutableAttributes: Record<string, string> = {};
  if (attributes.VisibilityTimeout) mutableAttributes.VisibilityTimeout = attributes.VisibilityTimeout;
  if (attributes.RedrivePolicy) mutableAttributes.RedrivePolicy = attributes.RedrivePolicy;
  if (Object.keys(mutableAttributes).length > 0) {
    await client.send(new SetQueueAttributesCommand({ QueueUrl: url, Attributes: mutableAttributes }));
  }
  const attributesResponse = await client.send(new GetQueueAttributesCommand({ QueueUrl: url, AttributeNames: ['QueueArn', 'RedrivePolicy', 'VisibilityTimeout'] }));
  if (!attributesResponse.Attributes?.QueueArn) throw new Error(`Cannot read SQS ARN for ${name}`);
  return { url, arn: attributesResponse.Attributes.QueueArn };
}

async function main() {
  const transactionDlq = await ensureQueue('wager-transactions-dlq.fifo');
  const eventDlq = await ensureQueue('wager-events-dlq.fifo');
  const transaction = await ensureQueue('wager-transactions.fifo', {
    VisibilityTimeout: '30', RedrivePolicy: JSON.stringify({ deadLetterTargetArn: transactionDlq.arn, maxReceiveCount: '6' }),
  });
  const events = await ensureQueue('wager-events.fifo', {
    VisibilityTimeout: '30', RedrivePolicy: JSON.stringify({ deadLetterTargetArn: eventDlq.arn, maxReceiveCount: '6' }),
  });
  process.env.SQS_QUEUE_URL = transaction.url;
  process.env.SQS_DLQ_URL = transactionDlq.url;
  process.env.SQS_OUTBOX_QUEUE_URL = events.url;
  process.env.SQS_OUTBOX_DLQ_URL = eventDlq.url;
  console.log(JSON.stringify({ queues: {
    transactions: transaction.url, transactionsDlq: transactionDlq.url,
    outboxEvents: events.url, outboxEventsDlq: eventDlq.url,
  } }));
}

main().catch(error => { console.error(JSON.stringify({ level: 'error', message: 'sqs_init_failed', error: String(error) })); process.exitCode = 1; });
