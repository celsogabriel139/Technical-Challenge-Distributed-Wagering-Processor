import { Entity, PrimaryKey, Property, Unique, Index } from '@mikro-orm/core';

@Entity({ tableName: 'wager_transactions' })
@Unique({ properties: ['idempotencyKey'] })
@Unique({ properties: ['providerId', 'externalTransactionId'] })
@Index({ properties: ['status', 'createdAt'] })
export class WagerTransactionEntity {
  @PrimaryKey({ type: 'uuid' }) id!: string;
  @Property() providerId!: string;
  @Property() externalTransactionId!: string;
  @Property() idempotencyKey!: string;
  @Property({ length: 64 }) payloadHash!: string;
  @Property({ type: 'uuid' }) walletId!: string;
  @Property({ type: 'uuid' }) playerId!: string;
  @Property() roundId!: string;
  @Property() gameId!: string;
  @Property() kind!: string;
  @Property({ columnType: 'numeric(20,2)' }) amount!: string;
  @Property({ length: 3 }) currency!: string;
  @Property({ nullable: true }) referenceExternalTransactionId?: string;
  @Property({ nullable: true, type: 'uuid' }) referenceTransactionId?: string;
  @Property({ default: 'PENDING' }) status = 'PENDING';
  @Property({ nullable: true }) failureCode?: string;
  @Property({ nullable: true, columnType: 'jsonb' }) originalResponse?: Record<string, unknown>;
  @Property() createdAt: Date = new Date();
  @Property({ nullable: true }) processedAt?: Date;
  @Property({ default: 0 }) referenceAttempts = 0;
  @Property({ nullable: true }) nextReferenceAttemptAt?: Date;
}
