import 'reflect-metadata';
import { MikroORM } from '@mikro-orm/postgresql';
import ormConfig from '../../mikro-orm.config';
import { WageringService } from '../../src/modules/wagering/wagering.service';
import { MetricsService } from '../../src/modules/metrics/metrics.service';
import { QueueService } from '../../src/modules/messaging/queue.service';

async function main() {
  const raw = process.argv[2];
  if (!raw) throw new Error('MISSING_CHILD_ARGUMENT');
  const args = JSON.parse(raw) as { action: 'submit' | 'queue' | 'crash-after-queue-commit'; input?: unknown; key?: string; consumerName?: string; messageId?: string; envelope?: unknown };
  const orm = await MikroORM.init(ormConfig);
  try {
    const service = new WageringService(orm.em.fork({ clear: true }), new MetricsService());
    let result: unknown;
    if (args.action === 'crash-after-queue-commit') {
      const queue = new QueueService();
      let found: { ReceiptHandle?: string; Body?: string } | undefined;
      for (let attempt = 0; attempt < 6 && !found; attempt++) {
        const batch = await queue.receive();
        for (const message of batch.Messages ?? []) {
          let decoded: { messageId?: string } | undefined;
          try { decoded = JSON.parse(message.Body ?? '') as { messageId?: string }; } catch { /* ignore unrelated messages */ }
          if (decoded?.messageId === args.messageId) found = message;
          else if (message.ReceiptHandle) await queue.release(message.ReceiptHandle, 30);
        }
      }
      if (!found?.ReceiptHandle || !found.Body) throw new Error('TEST_MESSAGE_NOT_RECEIVED');
      const envelope = JSON.parse(found.Body) as unknown;
      const done = await service.processQueueMessage(args.consumerName ?? 'wager-consumer-test', args.messageId ?? 'child-message', envelope);
      // Do not ack: reset visibility so the parent can immediately verify a real SQS redelivery.
      await queue.release(found.ReceiptHandle, 0);
      result = { committedWithoutAck: true, outcome: done };
      await queue.client.destroy();
    } else if (args.action === 'queue') {
      result = await service.processQueueMessage(args.consumerName ?? 'wager-consumer-test', args.messageId ?? 'child-message', args.envelope);
    } else {
      result = await service.submit(args.input as never, args.key ?? 'child-idempotency-key');
    }
    process.stdout.write(`RESULT_JSON:${JSON.stringify(result)}\n`);
  } finally {
    await orm.close(true);
  }
}
main().catch(error => {
  process.stderr.write(JSON.stringify({ errorType: error instanceof Error ? error.name : 'UNKNOWN_ERROR', message: String(error) }) + '\n');
  process.exitCode = 1;
});
