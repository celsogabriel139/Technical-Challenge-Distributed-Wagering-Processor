export enum WagerKind { Opening = 'OPENING', Bet = 'BET', Win = 'WIN', Loss = 'LOSS', Refund = 'REFUND', Rollback = 'ROLLBACK' }
export enum WagerStatus { Pending = 'PENDING', PendingReference = 'PENDING_REFERENCE', Processed = 'PROCESSED', Rejected = 'REJECTED', Failed = 'FAILED' }
export enum LedgerDirection { Debit = 'DEBIT', Credit = 'CREDIT' }
export type FailureCode =
  | 'INSUFFICIENT_FUNDS'
  | 'REFERENCE_NOT_FOUND'
  | 'REFERENCE_NOT_PROCESSED'
  | 'INVALID_REFERENCE_KIND'
  | 'REFERENCE_ALREADY_REVERSED'
  | 'REVERSAL_BALANCE_NEGATIVE'
  | 'REFERENCE_MISMATCH'
  | 'IDEMPOTENCY_KEY_PAYLOAD_CONFLICT'
  | 'EXTERNAL_TRANSACTION_ID_CONFLICT'
  | 'WALLET_BALANCE_LIMIT_EXCEEDED'
  | 'INVALID_OPERATION'
  | 'WALLET_NOT_FOUND';

export class DomainError extends Error {
  constructor(public readonly code: string, message = code) { super(message); this.name = 'DomainError'; }
}
