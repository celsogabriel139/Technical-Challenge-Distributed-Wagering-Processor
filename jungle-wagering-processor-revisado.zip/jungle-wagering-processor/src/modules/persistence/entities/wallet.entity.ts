import { Entity, PrimaryKey, Property, Unique } from '@mikro-orm/core';

@Entity({ tableName: 'wallets' })
@Unique({ properties: ['playerId', 'currency'] })
export class WalletEntity {
  @PrimaryKey({ type: 'uuid' }) id!: string;
  @Property({ type: 'uuid' }) playerId!: string;
  @Property({ length: 3 }) currency!: string;
  @Property({ columnType: 'numeric(20,2)', default: '0.00' }) balance!: string;
  @Property({ default: 1 }) version!: number;
  @Property() createdAt: Date = new Date();
  @Property({ onUpdate: () => new Date() }) updatedAt: Date = new Date();
}
