import 'reflect-metadata';
import { HttpException } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { QueueService } from './modules/messaging/queue.service';
import { WageringService } from './modules/wagering/wagering.service';
import { MetricsService } from './modules/metrics/metrics.service';
import { startMetricsServer, stopMetricsServer } from './metrics-server';

function retryDelay(receiveCount: number): number {
  return Math.min(300, 2 ** Math.min(Math.max(1, receiveCount), 8));
}

async function main() {
  const app = await NestFactory.createApplicationContext(AppModule, { logger: ['error', 'warn', 'log'] });
  const queue = app.get(QueueService);
  const wagers = app.get(WageringService);
  const metrics = app.get(MetricsService);
  const metricsServer = await startMetricsServer(metrics, Number(process.env.METRICS_PORT ?? 3001), 'wager-worker');
  let stopping = false;
  process.on('SIGTERM', () => { stopping = true; });
  process.on('SIGINT', () => { stopping = true; });

  while (!stopping) {
    let messages;
    try {
      const result = await queue.receive(1);
      messages = result.Messages ?? [];
    } catch (error) {
      console.error(JSON.stringify({ level: 'error', message: 'sqs_receive_failed', errorType: error instanceof Error ? error.name : 'UNKNOWN_ERROR' }));
      await new Promise(resolve => setTimeout(resolve, 1500));
      continue;
    }

    for (let index = 0; index < messages.length; index++) {
      const message = messages[index];
      if (stopping) {
        // Finish the current message, but release every not-yet-started receipt when SIGTERM
        // arrives so another worker can process it immediately instead of waiting 30 seconds.
        for (const pending of messages.slice(index)) {
          if (!pending.ReceiptHandle) continue;
          try { await queue.release(pending.ReceiptHandle, 0); }
          catch (error) {
            console.error(JSON.stringify({ level: 'warn', message: 'shutdown_visibility_release_failed', messageId: pending.MessageId, errorType: error instanceof Error ? error.name : 'UNKNOWN_ERROR' }));
          }
        }
        break;
      }
      if (!message.ReceiptHandle || !message.Body) continue;
      let parsed: unknown;
      try { parsed = JSON.parse(message.Body); }
      catch {
        try {
          await queue.sendToDeadLetterQueue({ rawBody: message.Body }, 'INVALID_JSON');
          await queue.ack(message.ReceiptHandle); metrics.deadLetter('invalid_json');
        } catch (error) {
          console.error(JSON.stringify({ level: 'error', message: 'dlq_publish_failed', messageId: message.MessageId, errorType: error instanceof Error ? error.name : 'UNKNOWN_ERROR' }));
          try { await queue.release(message.ReceiptHandle, 10); } catch { /* SQS visibility timeout will eventually expire. */ }
        }
        continue;
      }
      const envelope = parsed && typeof parsed === 'object' ? parsed as Record<string, unknown> : {};
      const messageId = typeof envelope.messageId === 'string' && envelope.messageId.length > 0 ? envelope.messageId : (message.MessageId ?? 'missing-message-id');
      try {
        // Service transaction includes inbox row, financial update, ledger and outbox. Ack follows commit.
        await wagers.processQueueMessage(process.env.CONSUMER_NAME ?? 'wager-consumer', messageId, parsed);
        await queue.ack(message.ReceiptHandle);
      } catch (error) {
        const status = error instanceof HttpException ? error.getStatus() : 0;
        const permanent = status >= 400 && status < 500;
        if (permanent) {
          try {
            await queue.sendToDeadLetterQueue({ messageId, body: message.Body }, error instanceof HttpException ? `HTTP_${status}` : 'PERMANENT_FAILURE');
            await queue.ack(message.ReceiptHandle);
            metrics.deadLetter(`http_${status}`);
            console.warn(JSON.stringify({ level: 'warn', message: 'sqs_message_dead_lettered', messageId, status }));
          } catch (dlqError) {
            console.error(JSON.stringify({ level: 'error', message: 'dlq_publish_failed', messageId, errorType: dlqError instanceof Error ? dlqError.name : 'UNKNOWN_ERROR' }));
            try { await queue.release(message.ReceiptHandle, 10); } catch { /* visibility timeout */ }
          }
        } else {
          const receiveCount = Number(message.Attributes?.ApproximateReceiveCount ?? 1);
          if (receiveCount >= 5) {
            try {
              await queue.sendToDeadLetterQueue({ messageId, body: message.Body }, 'RETRY_LIMIT_EXCEEDED');
              await queue.ack(message.ReceiptHandle);
              metrics.deadLetter('retry_limit_exceeded');
              console.warn(JSON.stringify({ level: 'warn', message: 'sqs_message_dead_lettered', messageId, receiveCount, reason: 'RETRY_LIMIT_EXCEEDED' }));
            } catch (dlqError) {
              console.error(JSON.stringify({ level: 'error', message: 'dlq_publish_failed', messageId, errorType: dlqError instanceof Error ? dlqError.name : 'UNKNOWN_ERROR' }));
              try { await queue.release(message.ReceiptHandle, 10); } catch { /* SQS redrive policy is the final fallback. */ }
            }
          } else {
            const delay = retryDelay(receiveCount);
            metrics.retry('sqs_consumer');
            console.error(JSON.stringify({ level: 'error', message: 'sqs_message_retry_scheduled', messageId, receiveCount, delaySeconds: delay, errorType: error instanceof Error ? error.name : 'UNKNOWN_ERROR' }));
            try { await queue.release(message.ReceiptHandle, delay); } catch { /* existing visibility timeout remains safe */ }
          }
        }
      }
    }
  }
  await app.close();
  await stopMetricsServer(metricsServer);
}

main().catch(error => { console.error(JSON.stringify({ level: 'fatal', message: 'consumer_failed', errorType: error instanceof Error ? error.name : 'UNKNOWN_ERROR' })); process.exitCode = 1; });
