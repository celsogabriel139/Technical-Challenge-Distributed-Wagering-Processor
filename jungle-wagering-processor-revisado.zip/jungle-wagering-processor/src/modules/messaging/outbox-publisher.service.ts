import { Injectable } from '@nestjs/common';
import { EntityManager } from '@mikro-orm/postgresql';
import { randomUUID } from 'node:crypto';
import { QueueService } from './queue.service';
import { MetricsService } from '../metrics/metrics.service';
import { OutboxMessageEntity } from '../persistence/entities/outbox-message.entity';

@Injectable()
export class OutboxPublisherService {
  constructor(private readonly rootEm: EntityManager, private readonly queue: QueueService, private readonly metrics: MetricsService) {}

  async processBatch(batchSize = 25): Promise<number> {
    const em = this.rootEm.fork({ clear: true });
    const claimToken = randomUUID();
    const now = new Date();
    const leaseUntil = new Date(now.getTime() + Number(process.env.OUTBOX_LEASE_MS ?? 60_000));
    const limit = Math.max(1, Math.min(100, Math.trunc(batchSize)));

    const claimed = await em.transactional(async tx => {
      const rows = await tx.getConnection().execute(
        `WITH candidates AS (
           SELECT id FROM outbox_messages
           WHERE published_at IS NULL
             AND (next_attempt_at IS NULL OR next_attempt_at <= ?)
             AND (lease_until IS NULL OR lease_until <= ?)
           ORDER BY created_at ASC, id ASC
           LIMIT ? FOR UPDATE SKIP LOCKED
         )
         UPDATE outbox_messages AS o
         SET claim_token = ?, lease_until = ?, attempts = o.attempts + 1
         FROM candidates c WHERE o.id = c.id
         RETURNING o.id`,
        [now, now, limit, claimToken, leaseUntil],
      ) as Array<{ id: string }>;
      return rows.map(row => row.id);
    });

    await this.updateLagGauge(em);
    // Publish a claimed batch concurrently so a slow endpoint cannot consume the entire lease
    // while unrelated events sit queued in this process. The database claim still partitions rows.
    await Promise.all(claimed.map(id => this.publishOne(id, claimToken)));
    return claimed.length;
  }

  private async publishOne(id: string, claimToken: string): Promise<void> {
    const em = this.rootEm.fork({ clear: true });
    const row = await em.findOne(OutboxMessageEntity, { id, claimToken });
    if (!row || row.publishedAt) return;
    try {
      await this.queue.sendEvent(row.payload);
      // If the process dies after SQS accepts the message and before this update, lease expiry
      // makes the row claimable again. Duplicate events carry the same eventId and are expected.
      await em.nativeUpdate(OutboxMessageEntity,
        { id, claimToken, publishedAt: null },
        { publishedAt: new Date(), claimToken: null, leaseUntil: null, nextAttemptAt: null, lastError: null },
      );
    } catch (error) {
      const delayMs = Math.min(300_000, 1000 * 2 ** Math.min(row.attempts, 8));
      const safeError = error instanceof Error ? error.name : 'UNKNOWN_ERROR';
      await em.nativeUpdate(OutboxMessageEntity,
        { id, claimToken, publishedAt: null },
        { nextAttemptAt: new Date(Date.now() + delayMs), claimToken: null, leaseUntil: null, lastError: safeError.slice(0, 500) },
      );
      this.metrics.retry('outbox');
      console.error(JSON.stringify({ level: 'error', message: 'outbox_publish_failed', eventId: id, eventType: row.eventType, attempts: row.attempts, errorType: safeError }));
    }
  }

  private async updateLagGauge(em: EntityManager): Promise<void> {
    try {
      const rows = await em.getConnection().execute(
        `SELECT COALESCE(EXTRACT(EPOCH FROM (NOW() - MIN(created_at))), 0) AS lag
         FROM outbox_messages WHERE published_at IS NULL`,
      ) as Array<{ lag: string | number }>;
      this.metrics.setOutboxLag(Number(rows[0]?.lag ?? 0));
    } catch { /* Metrics must not block message publication. */ }
  }
}
