import 'reflect-metadata';
import { MikroORM } from '@mikro-orm/postgresql';
import ormConfig from '../orm.config';

async function main(): Promise<void> {
  const direction = process.argv[2] ?? 'up';
  if (direction !== 'up' && direction !== 'down') {
    throw new Error('MIGRATION_DIRECTION_MUST_BE_UP_OR_DOWN');
  }

  const orm = await MikroORM.init(ormConfig);
  try {
    if (direction === 'up') {
      await orm.getMigrator().up();
      console.log(JSON.stringify({ level: 'info', message: 'migrations_applied' }));
    } else {
      await orm.getMigrator().down();
      console.log(JSON.stringify({ level: 'info', message: 'migrations_reverted' }));
    }
  } finally {
    await orm.close(true);
  }
}

main().catch(error => {
  console.error(JSON.stringify({ level: 'fatal', message: 'migration_failed', errorType: error instanceof Error ? error.name : 'UNKNOWN_ERROR' }));
  process.exitCode = 1;
});
