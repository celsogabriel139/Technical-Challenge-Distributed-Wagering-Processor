import { Module } from '@nestjs/common';
import { MikroOrmModule } from '@mikro-orm/nestjs';
import ormConfig from './orm.config';
import { WalletsController } from './modules/wallets/wallets.controller';
import { WageringController } from './modules/wagering/wagering.controller';
import { HealthController } from './modules/health/health.controller';
import { MetricsController } from './modules/metrics/metrics.controller';
import { WalletService } from './modules/wallets/wallet.service';
import { WageringService } from './modules/wagering/wagering.service';
import { QueueService } from './modules/messaging/queue.service';
import { OutboxPublisherService } from './modules/messaging/outbox-publisher.service';
import { MetricsService } from './modules/metrics/metrics.service';
import { ProviderIdentityGuard } from './modules/auth/provider-identity.guard';

@Module({
  imports: [MikroOrmModule.forRoot(ormConfig)],
  controllers: [WalletsController, WageringController, HealthController, MetricsController],
  providers: [WalletService, WageringService, QueueService, MetricsService, OutboxPublisherService, ProviderIdentityGuard],
  exports: [WageringService, QueueService, MetricsService, OutboxPublisherService],
})
export class AppModule {}
