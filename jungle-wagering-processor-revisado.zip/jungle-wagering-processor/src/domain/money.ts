import Decimal from 'decimal.js';
import { DomainError } from './wager.types';

// The largest supported amount has 20 significant digits; higher precision prevents
// Decimal.js's default precision from rounding intermediate monetary arithmetic.
Decimal.set({ precision: 40, rounding: Decimal.ROUND_HALF_UP });

export interface MoneyProps { amount: string; currency: string; }

const AMOUNT_PATTERN = /^(?:0|[1-9]\d{0,17})\.\d{2}$/;
const CURRENCY_PATTERN = /^[A-Z]{3}$/;
const ISO_4217_CURRENCIES = new Set((
  'AED AFN ALL AMD ANG AOA ARS AUD AWG AZN BAM BBD BDT BGN BHD BIF BMD BND BOB BOV BRL BSD BTN BWP BYN BZD CAD CDF CHE CHF CHW CLF CLP CNY COP COU CRC CUP CVE CZK DJF DKK DOP DZD EGP ERN ETB EUR FJD FKP GBP GEL GHS GIP GMD GNF GTQ GYD HKD HNL HTG HUF IDR ILS INR IQD IRR ISK JMD JOD JPY KES KGS KHR KMF KPW KRW KWD KYD KZT LAK LBP LKR LRD LSL LYD MAD MDL MGA MKD MMK MNT MOP MRU MUR MVR MWK MXN MXV MYR MZN NAD NGN NIO NOK NPR NZD OMR PAB PEN PGK PHP PKR PLN PYG QAR RON RSD RUB RWF SAR SBD SCR SDG SEK SGD SHP SLE SLL SOS SRD SSP STN SVC SYP SZL THB TJS TMT TND TOP TRY TTD TWD TZS UAH UGX USD USN UYI UYU UYW UZS VED VES VND VUV WST XAF XAG XAU XBA XBB XBC XBD XCD XDR XOF XPD XPF XPT XSU XTS XUA XXX YER ZAR ZMW ZWL'
).split(' '));

/** Immutable money value. Input values are non-negative, fixed-scale decimal strings.
 * Internal arithmetic may create a signed value (for negate/subtract), but never uses JS number.
 */
export class Money {
  private constructor(private readonly value: Decimal, public readonly currency: string) {}

  static from(props: MoneyProps): Money {
    if (!props || typeof props.amount !== 'string' || !AMOUNT_PATTERN.test(props.amount)) {
      throw new DomainError('INVALID_MONEY_FORMAT');
    }
    if (typeof props.currency !== 'string' || !CURRENCY_PATTERN.test(props.currency)) {
      throw new DomainError('INVALID_CURRENCY');
    }
    if (!ISO_4217_CURRENCIES.has(props.currency)) throw new DomainError('INVALID_CURRENCY');
    return new Money(new Decimal(props.amount), props.currency);
  }

  static zero(currency: string): Money {
    return Money.from({ amount: '0.00', currency });
  }

  private static fromDecimal(value: Decimal, currency: string): Money {
    if (value.decimalPlaces() > 2) throw new DomainError('MONEY_SCALE_OVERFLOW');
    if (value.abs().greaterThan('999999999999999999.99')) throw new DomainError('MONEY_OVERFLOW');
    return new Money(value, currency);
  }

  add(other: Money): Money {
    this.assertSameCurrency(other);
    return Money.fromDecimal(this.value.plus(other.value), this.currency);
  }

  subtract(other: Money): Money {
    this.assertSameCurrency(other);
    return Money.fromDecimal(this.value.minus(other.value), this.currency);
  }

  negate(): Money { return Money.fromDecimal(this.value.negated(), this.currency); }
  isZero(): boolean { return this.value.isZero(); }
  isPositive(): boolean { return this.value.isPositive(); }
  isNegative(): boolean { return this.value.isNegative(); }
  isLessThan(other: Money): boolean { this.assertSameCurrency(other); return this.value.lessThan(other.value); }
  equals(other: Money): boolean { this.assertSameCurrency(other); return this.value.equals(other.value); }
  toJSON(): MoneyProps { return { amount: this.toString(), currency: this.currency }; }
  toString(): string { return this.value.toFixed(2); }

  private assertSameCurrency(other: Money): void {
    if (this.currency !== other.currency) throw new DomainError('CURRENCY_MISMATCH');
  }
}
