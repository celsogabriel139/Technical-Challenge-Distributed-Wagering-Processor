import { Controller, Get, Res } from '@nestjs/common';
import { EntityManager } from '@mikro-orm/postgresql';
import { QueueService } from '../messaging/queue.service';

@Controller('health')
export class HealthController {
  constructor(private readonly em: EntityManager, private readonly queue: QueueService) {}

  @Get('live') live() { return { status: 'ok' }; }

  @Get('ready') async ready(@Res({ passthrough: true }) response: { status(code: number): unknown }) {
    let postgres = false;
    try { await this.em.getConnection().execute('select 1'); postgres = true; } catch { /* detail returned below */ }
    const sqs = await this.queue.checkReady();
    const ready = postgres && sqs;
    if (!ready) response.status(503);
    return { status: ready ? 'ready' : 'not_ready', dependencies: { postgres: postgres ? 'ready' : 'unavailable', sqs: sqs ? 'ready' : 'unavailable' } };
  }
}
