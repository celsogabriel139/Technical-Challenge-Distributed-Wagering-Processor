# Relatório de revisão e validação

**Versão do pacote:** 1.1.0 — revisão estática em 15/10/2026.

## Verificações executadas

- **Sintaxe TypeScript:** parser oficial do TypeScript percorreu os 40 arquivos `.ts` em `src/` e `test/`; 0 diagnósticos de sintaxe.
- **Manifestos:** `package.json` é JSON válido; `docker-compose.yml` é YAML válido e declara oito serviços (`postgres`, `localstack`, `migrate`, `sqs-init`, `api`, `worker`, `outbox-worker`, `pending-reference-worker`).
- **Auditoria estática:** busca por conversões de dinheiro via `parseFloat`, `toNumber` ou `Math` sobre valores monetários não encontrou ocorrências. Foram revisadas as regras de domínio, locks de wallet, cálculo decimal, idempotência persistente, inbox/outbox, fila de comandos separada da fila de eventos, referência fora de ordem, constraints e testes.
- **Revisões adicionais:** precisão de `decimal.js` definida acima dos 20 dígitos significativos suportados pela coluna `numeric(20,2)`; extensão `Migrator` registrada; comando de migration usa runner Bun explícito; falhas de serialização/deadlock após retries retornam erro transitório; publicação da outbox usa concorrência limitada ao lote já reclamado; referências existentes passam por validação de tipo/escopo antes de aguardar o processamento; `init-sqs.ts` normaliza os hosts retornados pelo LocalStack para o endpoint acessível no processo e o Compose configura a estratégia de endpoint `path`.
- **PostgreSQL:** sintaxe da combinação `CREATE CONSTRAINT TRIGGER ... UPDATE OF balance` conferida na documentação oficial do PostgreSQL.

## Validações bloqueadas neste ambiente

A compilação completa/typecheck e a execução de testes **não puderam ser certificadas**: não estão instalados Bun, Docker ou PostgreSQL/`psql`; `node_modules` não existe e a rede não permitiu instalar as dependências. `tsc --noEmit -p tsconfig.build.json` foi tentado, mas falhou com módulos e tipos ausentes (`@nestjs/*`, MikroORM, `decimal.js`, tipos do Node etc.); isso não confirma nem refuta erros de tipagem que só poderão ser determinados com dependências reais.

Assim, os testes unitários e os testes de integração com PostgreSQL e LocalStack estão preparados, mas **não foram executados nesta sessão**. Não se declara que a aplicação foi compilada, inicializada ou aprovada em runtime.

## Testes incluídos no pacote

Foram adicionados **14 testes unitários** e **21 testes de integração** (integração condicionada a `RUN_INTEGRATION_TESTS=1`). A quantidade de testes não representa aprovação: nenhum deles foi executado nesta sessão por falta do runtime/dependências e dos serviços reais.

- Unidade: precisão/escala monetária, valores inválidos, moeda inválida/incompatível, overflow, invariantes da wallet e ledger, estados de transação, referências e reversões.
- Integração real (requer PostgreSQL e LocalStack): 50 envios idênticos em paralelo; duas apostas concorrentes de 80,00 sobre saldo 100,00; wallets distintas; três processos OS; crash após commit e antes de ACK com redelivery; inbox/ledger/outbox atômicos; rollback de operação diante de falha na outbox; `REFUND`, `WIN` referenciado e `ROLLBACK` fora de ordem; tipo de referência incorreto; conflito de payload; reversão duplicada; constraints e imutabilidade de ledger; publishers concorrentes; retry da outbox; reconexão e reconciliação; DLQ.

## Como executar no ambiente de validação

Com Bun 1.x e Docker Compose instalados, e usando uma base/fila **dedicadas e descartáveis para testes**:

```bash
bun install
bun run test:unit

docker compose up -d postgres localstack
bun run init:sqs
bun run migration:up
bun run test:integration
```

Para validar typecheck e unitários:

```bash
bun run test:all
```

Para subir o serviço completo:

```bash
cp .env.example .env
docker compose up --build -d
docker compose ps
docker compose logs --tail=200 api worker outbox-worker pending-reference-worker
```

A suíte de integração contém testes que alteram filas e apagam registros da outbox; execute somente contra recursos locais descartáveis, nunca contra dados reais/compartilhados.

## Limites explícitos

A autenticação é omitida conforme permitido no enunciado e tem ponto de extensão `ProviderIdentityGuard`; antes de produção, substitua-a por OIDC via Identity Provider externo. O pacote não é uma plataforma financeira certificada. Ainda são necessários resultados verdes de build e integração num ambiente com serviços reais antes de ser tratado como aprovado para entrega ou produção.
