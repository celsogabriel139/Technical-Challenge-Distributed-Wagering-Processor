import { randomUUID } from 'node:crypto';
import { AnyIntegrationEvent } from './events';
import { DomainError } from './wager.types';

export interface OutboxMessageState {
  id: string; aggregateId: string; eventType: string; payload: Readonly<Record<string, unknown>>; occurredAt: Date;
  attempts: number; nextAttemptAt?: Date; publishedAt?: Date;
}
export class OutboxMessage {
  private constructor(public readonly id: string, public readonly aggregateId: string, public readonly eventType: string,
    public readonly payload: Readonly<Record<string, unknown>>, public readonly occurredAt: Date, private _attempts: number,
    private _nextAttemptAt?: Date, private _publishedAt?: Date) {}
  static enqueue(event: AnyIntegrationEvent): OutboxMessage {
    const payload = event.toJSON();
    return new OutboxMessage(event.eventId || randomUUID(), event.aggregateId, event.eventType, Object.freeze(payload), event.occurredAt, 0);
  }
  static rehydrate(state: OutboxMessageState): OutboxMessage {
    return new OutboxMessage(state.id, state.aggregateId, state.eventType, Object.freeze({ ...state.payload }), state.occurredAt, state.attempts, state.nextAttemptAt, state.publishedAt);
  }
  get attempts(): number { return this._attempts; }
  get nextAttemptAt(): Date | undefined { return this._nextAttemptAt; }
  get publishedAt(): Date | undefined { return this._publishedAt; }
  isPending(): boolean { return this._publishedAt === undefined; }
  isDue(now: Date): boolean { return this.isPending() && (!this._nextAttemptAt || this._nextAttemptAt <= now); }
  markPublished(at: Date): void { if (!this.isPending()) throw new DomainError('OUTBOX_ALREADY_PUBLISHED'); this._publishedAt = at; }
  scheduleRetry(now: Date): void {
    if (!this.isPending()) throw new DomainError('OUTBOX_ALREADY_PUBLISHED');
    this._attempts += 1;
    this._nextAttemptAt = new Date(now.getTime() + Math.min(300_000, 1000 * 2 ** Math.min(this._attempts, 8)));
  }
}
