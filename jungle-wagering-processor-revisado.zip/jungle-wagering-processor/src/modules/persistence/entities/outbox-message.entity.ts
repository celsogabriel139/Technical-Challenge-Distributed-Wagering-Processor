import { Entity, PrimaryKey, Property, Index } from '@mikro-orm/core';

@Entity({ tableName: 'outbox_messages' })
@Index({ properties: ['publishedAt', 'nextAttemptAt', 'createdAt'] })
export class OutboxMessageEntity {
  @PrimaryKey({ type: 'uuid' }) id!: string;
  @Property() aggregateId!: string;
  @Property() eventType!: string;
  @Property({ type: 'jsonb' }) payload!: Record<string, unknown>;
  @Property() createdAt: Date = new Date();
  @Property({ nullable: true }) publishedAt?: Date;
  @Property({ nullable: true }) nextAttemptAt?: Date;
  @Property({ nullable: true, type: 'uuid' }) claimToken?: string;
  @Property({ nullable: true }) leaseUntil?: Date;
  @Property({ default: 0 }) attempts = 0;
  @Property({ nullable: true }) lastError?: string;
}
