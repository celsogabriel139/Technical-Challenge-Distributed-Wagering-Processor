import { defineConfig } from '@mikro-orm/postgresql';
import { Migrator } from '@mikro-orm/migrations';
import { WalletEntity } from './modules/persistence/entities/wallet.entity';
import { WagerTransactionEntity } from './modules/persistence/entities/wager-transaction.entity';
import { LedgerEntryEntity } from './modules/persistence/entities/ledger-entry.entity';
import { InboxMessageEntity } from './modules/persistence/entities/inbox-message.entity';
import { OutboxMessageEntity } from './modules/persistence/entities/outbox-message.entity';

/** Shared runtime/CLI configuration. Imported by compiled application code and the MikroORM CLI. */
export default defineConfig({
  host: process.env.DB_HOST ?? 'localhost',
  port: Number(process.env.DB_PORT ?? 5432),
  user: process.env.DB_USER ?? 'postgres',
  password: process.env.DB_PASSWORD ?? 'postgres',
  dbName: process.env.DB_NAME ?? 'wagering',
  entities: [WalletEntity, WagerTransactionEntity, LedgerEntryEntity, InboxMessageEntity, OutboxMessageEntity],
  extensions: [Migrator],
  migrations: { path: 'dist/migrations', pathTs: 'src/migrations', transactional: true },
  debug: process.env.NODE_ENV === 'development',
  allowGlobalContext: false,
});
