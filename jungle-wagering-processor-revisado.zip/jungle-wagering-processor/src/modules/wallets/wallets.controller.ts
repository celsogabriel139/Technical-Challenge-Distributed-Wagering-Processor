import { Body, Controller, Get, Param, ParseUUIDPipe, Post, Query, ParseIntPipe, DefaultValuePipe } from '@nestjs/common';
import { WalletService } from './wallet.service';
import { ProviderIdentityGuard } from '../auth/provider-identity.guard';
import { UseGuards } from '@nestjs/common';
import { CreateWalletDto } from './dto/create-wallet.dto';

@Controller('wallets')
@UseGuards(ProviderIdentityGuard)
export class WalletsController {
  constructor(private readonly service: WalletService) {}
  @Post() create(@Body() body: CreateWalletDto) { return this.service.create(body); }
  @Get(':walletId') get(@Param('walletId', new ParseUUIDPipe()) id: string) { return this.service.get(id); }
  @Get(':walletId/ledger') ledger(
    @Param('walletId', new ParseUUIDPipe()) id: string,
    @Query('limit', new DefaultValuePipe(50), ParseIntPipe) limit: number,
    @Query('cursor') cursor?: string,
  ) { return this.service.ledger(id, limit, cursor); }
  @Post(':walletId/reconciliation') reconcile(@Param('walletId', new ParseUUIDPipe()) id: string) { return this.service.reconcile(id); }
}
