import { Entity, PrimaryKey, Property, Unique } from '@mikro-orm/core';

@Entity({ tableName: 'inbox_messages' })
@Unique({ properties: ['consumerName', 'messageId'] })
export class InboxMessageEntity {
  @PrimaryKey({ type: 'uuid' }) id!: string;
  @Property() consumerName!: string;
  @Property() messageId!: string;
  @Property({ length: 64 }) payloadHash!: string;
  @Property() receivedAt: Date = new Date();
  @Property({ nullable: true }) processedAt?: Date;
}
