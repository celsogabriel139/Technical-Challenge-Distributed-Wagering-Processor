import { Injectable, ConflictException, NotFoundException, BadRequestException } from '@nestjs/common';
import { EntityManager } from '@mikro-orm/postgresql';
import { createHash, randomUUID } from 'node:crypto';
import Decimal from 'decimal.js';
import { Money, MoneyProps } from '../../domain/money';
import { Wallet } from '../../domain/wallet';
import { WalletLedgerEntry } from '../../domain/wallet-ledger-entry';
import { WalletEntity } from '../persistence/entities/wallet.entity';
import { WagerTransactionEntity } from '../persistence/entities/wager-transaction.entity';
import { LedgerEntryEntity } from '../persistence/entities/ledger-entry.entity';
import { OutboxMessageEntity } from '../persistence/entities/outbox-message.entity';
import { WagerTransaction } from '../../domain/wager-transaction';
import { WagerKind, WagerStatus, LedgerDirection } from '../../domain/wager.types';
import { WagerTransactionProcessed, WalletBalanceChanged } from '../../domain/events';
import { MetricsService } from '../metrics/metrics.service';

@Injectable()
export class WalletService {
  constructor(private readonly em: EntityManager, private readonly metrics: MetricsService) {}

  async create(input: { playerId: string; initialBalance: MoneyProps }) {
    let money: Money;
    try { money = Money.from(input.initialBalance); }
    catch (e) { throw new BadRequestException((e as Error).message); }
    if (money.isNegative()) throw new BadRequestException('NEGATIVE_INITIAL_BALANCE');
    if (!input.playerId) throw new BadRequestException('PLAYER_ID_REQUIRED');
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(input.playerId)) throw new BadRequestException('PLAYER_ID_INVALID');

    const walletId = randomUUID();
    const now = new Date();
    const domainWallet = Wallet.open({ id: walletId, playerId: input.playerId, initialBalance: money, now });
    try {
      await this.em.transactional(async tx => {
        const wallet = tx.create(WalletEntity, {
          id: walletId, playerId: input.playerId, currency: money.currency, balance: money.toString(),
          version: domainWallet.version, createdAt: now, updatedAt: now,
        });
        tx.persist(wallet);
        await tx.flush();

        if (money.isPositive()) {
          const transactionId = randomUUID();
          const key = `opening:${walletId}`;
          const hash = createHash('sha256').update(`${walletId}|${money.currency}|${money.toString()}`).digest('hex');
          const domainTransaction = WagerTransaction.create({
            id: transactionId, providerId: 'internal', externalTransactionId: key, idempotencyKey: key,
            payloadHash: hash, walletId, playerId: input.playerId, roundId: 'internal', gameId: 'internal',
            kind: WagerKind.Opening, money, createdAt: now, internal: true,
          });
          domainTransaction.markProcessed(undefined, now);
          tx.persist(tx.create(WagerTransactionEntity, {
            id: transactionId, providerId: 'internal', externalTransactionId: key, idempotencyKey: key,
            payloadHash: hash, walletId, playerId: input.playerId, roundId: 'internal', gameId: 'internal',
            kind: WagerKind.Opening, amount: money.toString(), currency: money.currency,
            status: domainTransaction.status, createdAt: now, processedAt: now,
            originalResponse: { transactionId, status: WagerStatus.Processed, balance: money.toJSON(), idempotentReplay: false },
          }));
          const entry = WalletLedgerEntry.create({ id: randomUUID(), walletId, transactionId, direction: LedgerDirection.Credit,
            money, balanceBefore: Money.zero(money.currency), balanceAfter: money, walletVersion: 1, createdAt: now });
          tx.persist(tx.create(LedgerEntryEntity, {
            id: entry.id, walletId, transactionId, direction: entry.direction, amount: entry.money.toString(),
            balanceBefore: entry.balanceBefore.toString(), balanceAfter: entry.balanceAfter.toString(), currency: money.currency,
            walletVersion: entry.walletVersion, createdAt: entry.createdAt,
          }));
          const processed = WagerTransactionProcessed.create({ aggregateId: transactionId, correlationId: transactionId, occurredAt: now,
            data: { transactionId, providerId: 'internal', externalTransactionId: key, kind: WagerKind.Opening, status: WagerStatus.Processed } });
          const changed = WalletBalanceChanged.create({ aggregateId: walletId, correlationId: transactionId, occurredAt: now,
            data: { walletId, transactionId, direction: LedgerDirection.Credit, money: money.toJSON(),
              balanceBefore: Money.zero(money.currency).toJSON(), balanceAfter: money.toJSON(), walletVersion: 1 } });
          this.persistEvent(tx, processed); this.persistEvent(tx, changed);
        }
      });
    } catch (e) {
      if (this.isUniqueViolation(e)) throw new ConflictException('WALLET_ALREADY_EXISTS');
      throw e;
    }
    return { id: walletId, playerId: input.playerId, balance: money.toJSON(), version: 1, createdAt: now };
  }

  async get(walletId: string) {
    const wallet = await this.em.findOne(WalletEntity, { id: walletId });
    if (!wallet) throw new NotFoundException('WALLET_NOT_FOUND');
    return { id: wallet.id, playerId: wallet.playerId, balance: { amount: wallet.balance, currency: wallet.currency }, version: wallet.version, createdAt: wallet.createdAt, updatedAt: wallet.updatedAt };
  }

  async ledger(walletId: string, limit = 50, cursor?: string) {
    const wallet = await this.em.findOne(WalletEntity, { id: walletId });
    if (!wallet) throw new NotFoundException('WALLET_NOT_FOUND');
    if (!Number.isInteger(limit) || limit < 1 || limit > 100) throw new BadRequestException('INVALID_LEDGER_LIMIT');

    let cursorFilter: Record<string, unknown> = {};
    if (cursor) {
      let decoded: { createdAt: string; id: string };
      try { decoded = JSON.parse(Buffer.from(cursor, 'base64url').toString('utf8')); }
      catch { throw new BadRequestException('INVALID_LEDGER_CURSOR'); }
      if (!decoded || typeof decoded.createdAt !== 'string' || typeof decoded.id !== 'string' || Number.isNaN(Date.parse(decoded.createdAt))) {
        throw new BadRequestException('INVALID_LEDGER_CURSOR');
      }
      const createdAt = new Date(decoded.createdAt);
      cursorFilter = { $or: [{ createdAt: { $lt: createdAt } }, { createdAt, id: { $lt: decoded.id } }] };
    }
    const rows = await this.em.find(LedgerEntryEntity, { walletId, ...cursorFilter } as any, { orderBy: { createdAt: 'DESC', id: 'DESC' }, limit: limit + 1 });
    const hasMore = rows.length > limit;
    const page = rows.slice(0, limit);
    const last = page[page.length - 1];
    const nextCursor = hasMore && last ? Buffer.from(JSON.stringify({ createdAt: last.createdAt.toISOString(), id: last.id })).toString('base64url') : null;
    return {
      items: page.map(row => ({ id: row.id, walletId: row.walletId, transactionId: row.transactionId, direction: row.direction,
        money: { amount: row.amount, currency: row.currency }, balanceBefore: { amount: row.balanceBefore, currency: row.currency },
        balanceAfter: { amount: row.balanceAfter, currency: row.currency }, walletVersion: row.walletVersion, createdAt: row.createdAt })),
      nextCursor,
    };
  }

  async reconcile(walletId: string) {
    // Read balance and ledger aggregate in one SQL statement so a concurrent commit cannot
    // produce a false mismatch between two different READ COMMITTED snapshots.
    const rows = await this.em.getConnection().execute(
      `SELECT w.id AS wallet_id, w.balance::text AS stored_balance, w.currency,
              COALESCE(SUM(CASE WHEN l.direction = 'CREDIT' THEN l.amount ELSE -l.amount END), 0)::text AS calculated_balance,
              COUNT(l.id)::int AS checked_entries, w.version AS wallet_version
       FROM wallets w
       LEFT JOIN wallet_ledger_entries l ON l.wallet_id = w.id
       WHERE w.id = ?
       GROUP BY w.id, w.balance, w.currency, w.version`,
      [walletId],
    ) as Array<{ wallet_id: string; stored_balance: string; currency: string; calculated_balance: string; checked_entries: number; wallet_version: number }>;
    const row = rows[0];
    if (!row) throw new NotFoundException('WALLET_NOT_FOUND');
    const stored = new Decimal(row.stored_balance);
    const calculated = new Decimal(row.calculated_balance);
    const difference = stored.minus(calculated).toFixed(2);
    const consistent = difference === '0.00';
    if (!consistent) {
      this.metrics.reconciliationMismatch();
      console.error(JSON.stringify({ level: 'error', message: 'wallet_reconciliation_mismatch', walletId, walletVersion: row.wallet_version, checkedEntries: row.checked_entries }));
    }
    return { walletId, storedBalance: { amount: stored.toFixed(2), currency: row.currency }, calculatedBalance: { amount: calculated.toFixed(2), currency: row.currency }, difference: { amount: difference, currency: row.currency }, consistent, checkedEntries: Number(row.checked_entries) };
  }

  private persistEvent(tx: EntityManager, event: WagerTransactionProcessed | WalletBalanceChanged) {
    const payload = event.toJSON();
    tx.persist(tx.create(OutboxMessageEntity, { id: event.eventId, aggregateId: event.aggregateId, eventType: event.eventType, payload, createdAt: event.occurredAt, attempts: 0 }));
  }
  private isUniqueViolation(e: unknown): boolean {
    let cursor: any = e;
    while (cursor) { if (cursor.code === '23505' || cursor.name === 'UniqueConstraintViolationException') return true; cursor = cursor.cause; }
    return /unique constraint|duplicate key/i.test(String(e));
  }
}
