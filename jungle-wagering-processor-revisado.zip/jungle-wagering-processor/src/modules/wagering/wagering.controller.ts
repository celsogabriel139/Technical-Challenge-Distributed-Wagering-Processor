import { Body, Controller, Get, Headers, HttpCode, Param, ParseUUIDPipe, Post, Res } from '@nestjs/common';
import { WageringService, WagerInput } from './wagering.service';
import { ProviderIdentityGuard } from '../auth/provider-identity.guard';
import { UseGuards } from '@nestjs/common';
import { SubmitWagerDto } from './dto/submit-wager.dto';

@Controller()
@UseGuards(ProviderIdentityGuard)
export class WageringController {
  constructor(private readonly service: WageringService) {}

  @Post('wagering/transactions')
  @HttpCode(200)
  async submit(
    @Body() body: SubmitWagerDto,
    @Headers('idempotency-key') key: string | undefined,
    @Res({ passthrough: true }) response: { status(code: number): unknown },
  ) {
    const result = await this.service.submit(body as WagerInput, key ?? '');
    response.status(result.status === 'PENDING_REFERENCE' || result.status === 'PENDING' ? 202 : result.status === 'REJECTED' ? 422 : 200);
    return result;
  }

  @Get('wagering/transactions/:transactionId')
  get(@Param('transactionId', new ParseUUIDPipe()) id: string) { return this.service.get(id); }

  @Get('providers/:providerId/wagering/transactions/:externalTransactionId')
  getExternal(@Param('providerId') providerId: string, @Param('externalTransactionId') externalId: string) { return this.service.getExternal(providerId, externalId); }
}
