import { Injectable } from '@nestjs/common';
import {
  SQSClient, SendMessageCommand, ReceiveMessageCommand, DeleteMessageCommand,
  ChangeMessageVisibilityCommand, GetQueueAttributesCommand, GetQueueUrlCommand,
} from '@aws-sdk/client-sqs';
import { createHash } from 'node:crypto';

@Injectable()
export class QueueService {
  readonly client = new SQSClient({
    region: process.env.AWS_REGION ?? 'us-east-1',
    endpoint: process.env.SQS_ENDPOINT ?? undefined,
    credentials: {
      accessKeyId: process.env.AWS_ACCESS_KEY_ID ?? 'test',
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY ?? 'test',
    },
    maxAttempts: 3,
  });

  private transactionQueueUrl(): string {
    const url = process.env.SQS_QUEUE_URL;
    if (!url) throw new Error('SQS_QUEUE_URL_NOT_CONFIGURED');
    return url;
  }
  private outboxQueueUrl(): string {
    const url = process.env.SQS_OUTBOX_QUEUE_URL;
    if (!url) throw new Error('SQS_OUTBOX_QUEUE_URL_NOT_CONFIGURED');
    return url;
  }

  /** Public helper for integration tests and provider adapters. */
  async sendTransactionRequest(envelope: unknown, groupId?: string, deduplicationId?: string) {
    const body = JSON.stringify(envelope);
    const data = envelope && typeof envelope === 'object' ? (envelope as { data?: { walletId?: unknown } }).data : undefined;
    const inferredGroup = typeof data?.walletId === 'string' && data.walletId ? data.walletId : 'wager-transactions';
    const resolvedGroup = groupId?.trim() ? groupId.trim() : inferredGroup;
    return this.client.send(new SendMessageCommand({
      QueueUrl: this.transactionQueueUrl(), MessageBody: body,
      MessageGroupId: resolvedGroup.slice(0, 128),
      MessageDeduplicationId: (deduplicationId ?? createHash('sha256').update(body).digest('hex')).slice(0, 128),
    }));
  }

  /** Outbox integration events go to a separate queue, never back to the command consumer. */
  async sendEvent(envelope: Record<string, any>) {
    const body = JSON.stringify(envelope);
    return this.client.send(new SendMessageCommand({
      QueueUrl: this.outboxQueueUrl(), MessageBody: body,
      MessageGroupId: String(envelope.aggregateId ?? 'integration-events').slice(0, 128),
      MessageDeduplicationId: String(envelope.eventId ?? createHash('sha256').update(body).digest('hex')).slice(0, 128),
    }));
  }

  async receive(maxMessages = 10) {
    const safeMax = Math.max(1, Math.min(10, Math.trunc(maxMessages)));
    return this.client.send(new ReceiveMessageCommand({
      QueueUrl: this.transactionQueueUrl(), MaxNumberOfMessages: safeMax,
      WaitTimeSeconds: 10, VisibilityTimeout: 30,
      MessageSystemAttributeNames: ['ApproximateReceiveCount'],
    }));
  }
  async ack(receiptHandle: string) {
    return this.client.send(new DeleteMessageCommand({ QueueUrl: this.transactionQueueUrl(), ReceiptHandle: receiptHandle }));
  }
  async release(receiptHandle: string, seconds = 10) {
    return this.client.send(new ChangeMessageVisibilityCommand({ QueueUrl: this.transactionQueueUrl(), ReceiptHandle: receiptHandle, VisibilityTimeout: seconds }));
  }

  async sendToDeadLetterQueue(envelope: unknown, reason: string): Promise<void> {
    const url = process.env.SQS_DLQ_URL;
    if (!url) throw new Error('SQS_DLQ_URL_NOT_CONFIGURED');
    const body = JSON.stringify({ reason, failedAt: new Date().toISOString(), originalMessage: envelope });
    // Stable deduplication ID for retries of the same failure; failedAt is intentionally excluded.
    const deduplicationId = createHash('sha256').update(JSON.stringify({ reason, envelope })).digest('hex').slice(0, 128);
    await this.client.send(new SendMessageCommand({ QueueUrl: url, MessageBody: body,
      MessageGroupId: 'wager-transactions-dlq', MessageDeduplicationId: deduplicationId }));
  }

  async checkReady(): Promise<boolean> {
    try {
      const urls = [
        this.transactionQueueUrl(),
        this.outboxQueueUrl(),
        process.env.SQS_DLQ_URL,
        process.env.SQS_OUTBOX_DLQ_URL,
      ];
      if (urls.some(url => !url)) return false;
      await Promise.all(urls.map(QueueUrl => this.client.send(
        new GetQueueAttributesCommand({ QueueUrl: QueueUrl!, AttributeNames: ['QueueArn'] }),
      )));
      return true;
    } catch { return false; }
  }

  async getQueueUrl(name: string): Promise<string> {
    if (name === 'wager-transactions.fifo' && process.env.SQS_QUEUE_URL) return process.env.SQS_QUEUE_URL;
    if (name === 'wager-events.fifo' && process.env.SQS_OUTBOX_QUEUE_URL) return process.env.SQS_OUTBOX_QUEUE_URL;
    const response = await this.client.send(new GetQueueUrlCommand({ QueueName: name }));
    if (!response.QueueUrl) throw new Error(`SQS_QUEUE_URL_NOT_FOUND:${name}`);
    return response.QueueUrl;
  }
}
