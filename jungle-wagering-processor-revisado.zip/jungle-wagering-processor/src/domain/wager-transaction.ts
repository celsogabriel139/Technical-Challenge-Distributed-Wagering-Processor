import { Money } from './money';
import { DomainError, FailureCode, WagerKind, WagerStatus, LedgerDirection } from './wager.types';

export interface WagerTransactionState {
  id: string; providerId: string; externalTransactionId: string; idempotencyKey: string; payloadHash: string;
  walletId: string; playerId: string; roundId: string; gameId: string; kind: WagerKind; money: Money;
  referenceExternalTransactionId?: string; createdAt: Date; status: WagerStatus;
  referenceTransactionId?: string; failureCode?: FailureCode; processedAt?: Date;
}

export class WagerTransaction {
  private constructor(
    public readonly id: string, public readonly providerId: string, public readonly externalTransactionId: string,
    public readonly idempotencyKey: string, public readonly payloadHash: string, public readonly walletId: string,
    public readonly playerId: string, public readonly roundId: string, public readonly gameId: string,
    public readonly kind: WagerKind, public readonly money: Money,
    public readonly referenceExternalTransactionId: string | undefined, public readonly createdAt: Date,
    private _status: WagerStatus, private _referenceTransactionId?: string,
    private _failureCode?: FailureCode, private _processedAt?: Date,
  ) {}

  static create(props: Omit<WagerTransactionState, 'status' | 'referenceTransactionId' | 'failureCode' | 'processedAt'> & { internal?: boolean }): WagerTransaction {
    if (props.kind === WagerKind.Opening && !props.internal) throw new DomainError('OPENING_IS_INTERNAL');
    if ((props.kind === WagerKind.Refund || props.kind === WagerKind.Rollback) && !props.referenceExternalTransactionId) throw new DomainError('REFERENCE_REQUIRED');
    if (props.referenceExternalTransactionId && props.referenceExternalTransactionId === props.externalTransactionId) throw new DomainError('SELF_REFERENCE_NOT_ALLOWED');
    if (props.referenceExternalTransactionId && ![WagerKind.Win, WagerKind.Refund, WagerKind.Rollback].includes(props.kind)) throw new DomainError('REFERENCE_NOT_ALLOWED_FOR_KIND');
    if (!props.money.isPositive()) throw new DomainError('AMOUNT_MUST_BE_POSITIVE');
    return new WagerTransaction(props.id, props.providerId, props.externalTransactionId, props.idempotencyKey, props.payloadHash,
      props.walletId, props.playerId, props.roundId, props.gameId, props.kind, props.money,
      props.referenceExternalTransactionId, props.createdAt, WagerStatus.Pending);
  }

  static rehydrate(state: WagerTransactionState): WagerTransaction {
    return new WagerTransaction(state.id, state.providerId, state.externalTransactionId, state.idempotencyKey, state.payloadHash,
      state.walletId, state.playerId, state.roundId, state.gameId, state.kind, state.money,
      state.referenceExternalTransactionId, state.createdAt, state.status, state.referenceTransactionId, state.failureCode, state.processedAt);
  }

  get status(): WagerStatus { return this._status; }
  get referenceTransactionId(): string | undefined { return this._referenceTransactionId; }
  get failureCode(): FailureCode | undefined { return this._failureCode; }
  get processedAt(): Date | undefined { return this._processedAt; }
  isTerminal(): boolean { return [WagerStatus.Processed, WagerStatus.Rejected, WagerStatus.Failed].includes(this._status); }
  affectsBalance(): boolean { return [WagerKind.Bet, WagerKind.Win, WagerKind.Refund, WagerKind.Rollback].includes(this.kind); }
  requiresReference(): boolean { return this.kind === WagerKind.Refund || this.kind === WagerKind.Rollback; }
  matchesPayload(payloadHash: string): boolean { return this.payloadHash === payloadHash; }
  ledgerDirectionFor(reference?: WagerTransaction): LedgerDirection | undefined {
    if (this.kind === WagerKind.Bet) return LedgerDirection.Debit;
    if (this.kind === WagerKind.Win) return LedgerDirection.Credit;
    if (this.kind === WagerKind.Loss || this.kind === WagerKind.Opening) return undefined;
    if (!reference) return undefined;
    return reference.kind === WagerKind.Bet ? LedgerDirection.Credit : LedgerDirection.Debit;
  }

  markProcessed(referenceTransactionId: string | undefined, at: Date): void {
    this.assertNonTerminal(); this._status = WagerStatus.Processed; this._referenceTransactionId = referenceTransactionId; this._processedAt = at; this._failureCode = undefined;
  }
  markPendingReference(): void {
    this.assertNonTerminal();
    if (!this.referenceExternalTransactionId || (!this.requiresReference() && this.kind !== WagerKind.Win)) throw new DomainError('REFERENCE_NOT_ALLOWED_FOR_KIND');
    this._status = WagerStatus.PendingReference;
  }
  reject(code: FailureCode, at = new Date(), referenceTransactionId?: string): void {
    this.assertNonTerminal(); this._status = WagerStatus.Rejected; this._failureCode = code; this._referenceTransactionId = referenceTransactionId; this._processedAt = at;
  }
  fail(code: FailureCode, at = new Date()): void {
    this.assertNonTerminal(); this._status = WagerStatus.Failed; this._failureCode = code; this._processedAt = at;
  }
  private assertNonTerminal(): void { if (this.isTerminal()) throw new DomainError('INVALID_TRANSACTION_STATE'); }
}
