import { IsString, Matches } from 'class-validator';

export class MoneyDto {
  @IsString()
  @Matches(/^(?:0|[1-9]\d{0,17})\.\d{2}$/, { message: 'amount must be a non-negative decimal string with exactly two decimal places' })
  amount!: string;

  @IsString()
  @Matches(/^[A-Z]{3}$/, { message: 'currency must be a three-letter uppercase ISO-4217 code' })
  currency!: string;
}
