import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { WageringService } from './modules/wagering/wagering.service';
import { MetricsService } from './modules/metrics/metrics.service';
import { startMetricsServer, stopMetricsServer } from './metrics-server';

async function main() {
  const app = await NestFactory.createApplicationContext(AppModule, { logger: ['error', 'warn', 'log'] });
  const service = app.get(WageringService);
  const metricsServer = await startMetricsServer(app.get(MetricsService), Number(process.env.METRICS_PORT ?? 3003), 'pending-reference-worker');
  let stopping = false;
  process.on('SIGTERM', () => { stopping = true; });
  process.on('SIGINT', () => { stopping = true; });
  while (!stopping) {
    try {
      const processed = await service.retryPendingReferences(100);
      if (processed === 0) await new Promise(resolve => setTimeout(resolve, Math.max(100, Number(process.env.PENDING_REFERENCE_POLL_MS ?? 1000))));
    } catch (error) {
      console.error(JSON.stringify({ level: 'error', message: 'pending_reference_retry_failed', errorType: error instanceof Error ? error.name : 'UNKNOWN_ERROR' }));
      await new Promise(resolve => setTimeout(resolve, 1500));
    }
  }
  await app.close();
  await stopMetricsServer(metricsServer);
}
main().catch(error => { console.error(JSON.stringify({ level: 'fatal', message: 'pending_reference_worker_failed', errorType: error instanceof Error ? error.name : 'UNKNOWN_ERROR' })); process.exitCode = 1; });
