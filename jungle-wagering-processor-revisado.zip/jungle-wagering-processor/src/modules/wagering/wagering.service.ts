import { Injectable, ConflictException, NotFoundException, BadRequestException, ServiceUnavailableException } from '@nestjs/common';
import { EntityManager } from '@mikro-orm/postgresql';
import { LockMode } from '@mikro-orm/core';
import { createHash, randomUUID } from 'node:crypto';
import Decimal from 'decimal.js';
import { Money, MoneyProps } from '../../domain/money';
import { Wallet } from '../../domain/wallet';
import { WalletLedgerEntry } from '../../domain/wallet-ledger-entry';
import { WagerTransaction } from '../../domain/wager-transaction';
import { DomainError, FailureCode, LedgerDirection, WagerKind, WagerStatus } from '../../domain/wager.types';
import { WagerTransactionProcessed, WagerTransactionRejected, WagerTransactionPendingReference, WalletBalanceChanged, AnyIntegrationEvent } from '../../domain/events';
import { LedgerEntryEntity } from '../persistence/entities/ledger-entry.entity';
import { WalletEntity } from '../persistence/entities/wallet.entity';
import { WagerTransactionEntity } from '../persistence/entities/wager-transaction.entity';
import { OutboxMessageEntity } from '../persistence/entities/outbox-message.entity';
import { InboxMessageEntity } from '../persistence/entities/inbox-message.entity';
import { MetricsService } from '../metrics/metrics.service';

export interface WagerInput {
  providerId: string;
  externalTransactionId: string;
  playerId: string;
  walletId: string;
  roundId: string;
  gameId: string;
  kind: 'BET'|'WIN'|'LOSS'|'REFUND'|'ROLLBACK';
  money: MoneyProps;
  referenceExternalTransactionId?: string;
}

export interface WagerResult {
  transactionId: string;
  status: WagerStatus | string;
  balance: MoneyProps | null;
  idempotentReplay: boolean;
  failureCode?: string;
}

interface PreparedWager { input: WagerInput; key: string; money: Money; payloadHash: string; }
interface Evaluation { pendingReference: boolean; balance: Money; }

function canonical(value: unknown): string {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  const obj = value as Record<string, unknown>;
  return `{${Object.keys(obj).sort().map(key => `${JSON.stringify(key)}:${canonical(obj[key])}`).join(',')}}`;
}
function sha256(value: unknown): string { return createHash('sha256').update(typeof value === 'string' ? value : canonical(value)).digest('hex'); }
function isUniqueViolation(error: unknown): boolean {
  let current: any = error;
  while (current) {
    if (current.code === '23505' || current.name === 'UniqueConstraintViolationException') return true;
    current = current.cause;
  }
  return /unique constraint|duplicate key/i.test(String(error));
}
function postgresCode(error: unknown): string | undefined {
  let current: any = error;
  while (current) { if (typeof current.code === 'string') return current.code; current = current.cause; }
  return undefined;
}
function isRetryableDatabaseConflict(error: unknown): boolean { return ['40001', '40P01', '55P03'].includes(postgresCode(error) ?? ''); }

@Injectable()
export class WageringService {
  constructor(private readonly em: EntityManager, private readonly metrics: MetricsService) {}

  async submit(input: WagerInput, idempotencyKey: string): Promise<WagerResult> {
    const prepared = this.prepare(input, idempotencyKey);
    const stopTimer = this.metrics.startProcessingTimer(input.kind);
    let finalStatus = 'ERROR';
    try {
      const result = await this.withDatabaseRetry(() => this.em.transactional(tx => this.processInTransaction(tx, prepared)));
      finalStatus = String(result.status);
      if (result.idempotentReplay) this.metrics.duplicate('idempotency_key');
      else this.metrics.transaction(String(result.status));
      console.log(JSON.stringify({ level: 'info', message: 'wager_submission_finished', correlationId: result.transactionId, transactionId: result.transactionId, providerId: input.providerId, walletId: input.walletId, status: result.status, replay: result.idempotentReplay }));
      return result;
    } catch (error) {
      if (isUniqueViolation(error)) {
        const recovered = await this.recoverUniqueConflict(prepared);
        finalStatus = String(recovered.status);
        return recovered;
      }
      this.metrics.transaction('ERROR');
      if (isRetryableDatabaseConflict(error)) {
        this.metrics.lockConflict(postgresCode(error) ?? 'UNKNOWN');
        // Exhausted serialization/deadlock retries are transient infrastructure failures,
        // not permanent business errors. A caller can safely retry with the same idempotency key.
        throw new ServiceUnavailableException('DATABASE_CONFLICT_RETRY_EXHAUSTED');
      }
      if (this.isConnectionFailure(error)) throw new ServiceUnavailableException('DATABASE_TEMPORARILY_UNAVAILABLE');
      throw error;
    } finally { this.metrics.finishProcessingTimer(stopTimer, finalStatus); }
  }

  /** Atomically records inbox + transaction + wallet + ledger + outbox in one SQL transaction. */
  async processQueueMessage(consumerName: string, messageId: string, envelope: unknown): Promise<{ duplicate: boolean; result?: WagerResult }> {
    if (!messageId || messageId.length > 255) throw new BadRequestException('INVALID_MESSAGE_ID');
    if (!consumerName || consumerName.length > 255) throw new BadRequestException('INVALID_CONSUMER_NAME');
    const parsed = this.parseQueueEnvelope(envelope);
    const prepared = this.prepare(parsed.input, parsed.key);
    const payloadHash = sha256(envelope);
    const stopTimer = this.metrics.startProcessingTimer(prepared.input.kind);
    let status = 'ERROR';
    try {
      const outcome = await this.withDatabaseRetry(() => this.em.transactional(async tx => {
        // ON CONFLICT + FOR UPDATE works across workers/processes; there is no in-memory dedupe.
        await tx.getConnection().execute(
          `INSERT INTO inbox_messages (id, consumer_name, message_id, payload_hash, received_at)
           VALUES (?, ?, ?, ?, ?) ON CONFLICT (consumer_name, message_id) DO NOTHING`,
          [randomUUID(), consumerName, messageId, payloadHash, new Date()],
        );
        const rows = await tx.getConnection().execute(
          `SELECT id, payload_hash, processed_at FROM inbox_messages
           WHERE consumer_name = ? AND message_id = ? FOR UPDATE`, [consumerName, messageId],
        ) as Array<{ id: string; payload_hash: string; processed_at: Date | null }>;
        const inbox = rows[0];
        if (!inbox) throw new Error('INBOX_ROW_NOT_FOUND_AFTER_INSERT');
        if (inbox.payload_hash !== payloadHash) throw new ConflictException('MESSAGE_ID_PAYLOAD_CONFLICT');
        if (inbox.processed_at) return { duplicate: true as const };

        const result = await this.processInTransaction(tx, prepared);
        await tx.getConnection().execute('UPDATE inbox_messages SET processed_at = ? WHERE id = ?', [new Date(), inbox.id]);
        return { duplicate: false as const, result };
      }));

      if (outcome.duplicate) {
        status = 'DUPLICATE'; this.metrics.duplicate('sqs_inbox');
        return { duplicate: true };
      }
      status = String(outcome.result.status);
      if (outcome.result.idempotentReplay) this.metrics.duplicate('idempotency_key');
      else this.metrics.transaction(String(outcome.result.status));
      console.log(JSON.stringify({ level: 'info', message: 'sqs_message_processed', correlationId: outcome.result.transactionId, messageId, transactionId: outcome.result.transactionId, providerId: parsed.input.providerId, walletId: parsed.input.walletId, status: outcome.result.status }));
      return { duplicate: false, result: outcome.result };
    } catch (error) {
      if (isUniqueViolation(error)) {
        // A concurrent request may have won the durable idempotency-key race. Its financial
        // transaction already committed; record this distinct queue delivery in inbox in a
        // follow-up SQL transaction before acknowledging it. No financial effect is replayed.
        const result = await this.recoverUniqueConflict(prepared);
        const inboxEm = this.em.fork({ clear: true });
        await inboxEm.transactional(async tx => {
          await tx.getConnection().execute(
            `INSERT INTO inbox_messages (id, consumer_name, message_id, payload_hash, received_at)
             VALUES (?, ?, ?, ?, ?) ON CONFLICT (consumer_name, message_id) DO NOTHING`,
            [randomUUID(), consumerName, messageId, payloadHash, new Date()],
          );
          const inboxRows = await tx.getConnection().execute(
            `SELECT id, payload_hash FROM inbox_messages WHERE consumer_name = ? AND message_id = ? FOR UPDATE`,
            [consumerName, messageId],
          ) as Array<{ id: string; payload_hash: string }>;
          const inbox = inboxRows[0];
          if (!inbox) throw new Error('INBOX_ROW_NOT_FOUND_AFTER_UNIQUE_RACE');
          if (inbox.payload_hash !== payloadHash) throw new ConflictException('MESSAGE_ID_PAYLOAD_CONFLICT');
          await tx.getConnection().execute('UPDATE inbox_messages SET processed_at = COALESCE(processed_at, ?) WHERE id = ?', [new Date(), inbox.id]);
        });
        status = String(result.status);
        return { duplicate: false, result: { ...result, idempotentReplay: true } };
      }
      this.metrics.transaction('ERROR');
      if (isRetryableDatabaseConflict(error)) {
        this.metrics.lockConflict(postgresCode(error) ?? 'UNKNOWN');
        // Exhausted serialization/deadlock retries are transient infrastructure failures,
        // not permanent business errors. A caller can safely retry with the same idempotency key.
        throw new ServiceUnavailableException('DATABASE_CONFLICT_RETRY_EXHAUSTED');
      }
      if (this.isConnectionFailure(error)) throw new ServiceUnavailableException('DATABASE_TEMPORARILY_UNAVAILABLE');
      throw error;
    } finally { this.metrics.finishProcessingTimer(stopTimer, status); }
  }

  async get(id: string) {
    const row = await this.em.findOne(WagerTransactionEntity, { id });
    if (!row) throw new NotFoundException('TRANSACTION_NOT_FOUND');
    return this.toPublicTransaction(row);
  }

  async getExternal(providerId: string, externalTransactionId: string) {
    const row = await this.em.findOne(WagerTransactionEntity, { providerId, externalTransactionId });
    if (!row) throw new NotFoundException('TRANSACTION_NOT_FOUND');
    return this.toPublicTransaction(row);
  }

  /** Scheduled retry. Reference lookup and financial mutation are repeatable and transactionally guarded. */
  async retryPendingReferences(limit = 100): Promise<number> {
    const batchSize = Math.max(1, Math.min(500, Math.trunc(limit)));
    let retried = 0;
    // One wallet/reference per SQL transaction avoids holding many wallet locks together.
    // SKIP LOCKED lets multiple scheduler instances partition the due work safely.
    while (retried < batchSize) {
      const didWork = await this.withDatabaseRetry(() => this.em.transactional(async tx => {
        const now = new Date();
        const due = await tx.getConnection().execute(
          `SELECT id FROM wager_transactions
           WHERE status = 'PENDING_REFERENCE' AND next_reference_attempt_at <= ?
           ORDER BY next_reference_attempt_at ASC, created_at ASC
           LIMIT 1 FOR UPDATE SKIP LOCKED`, [now],
        ) as Array<{ id: string }>;
        const candidate = due[0];
        if (!candidate) return false;
        const wager = await tx.findOne(WagerTransactionEntity, { id: candidate.id });
        if (!wager || wager.status !== WagerStatus.PendingReference) return false;
        await this.retryOnePendingReference(tx, wager, now);
        await tx.flush();
        if ([WagerStatus.Processed, WagerStatus.Rejected, WagerStatus.Failed].includes(wager.status as WagerStatus)) {
          this.metrics.transaction(String(wager.status));
        }
        return true;
      }));
      if (!didWork) break;
      retried += 1;
    }
    return retried;
  }

  private prepare(input: WagerInput, idempotencyKey: string): PreparedWager {
    if (!idempotencyKey || typeof idempotencyKey !== 'string' || !idempotencyKey.trim()) throw new BadRequestException('IDEMPOTENCY_KEY_REQUIRED');
    if (idempotencyKey.length > 255) throw new BadRequestException('IDEMPOTENCY_KEY_TOO_LONG');
    if (!input || !['BET','WIN','LOSS','REFUND','ROLLBACK'].includes(input.kind)) throw new BadRequestException('INVALID_KIND');
    for (const [name, value] of Object.entries({ providerId: input.providerId, externalTransactionId: input.externalTransactionId, playerId: input.playerId, walletId: input.walletId, roundId: input.roundId, gameId: input.gameId })) {
      if (typeof value !== 'string' || !value.trim()) throw new BadRequestException(`${name.toUpperCase()}_REQUIRED`);
      if (value.length > 255) throw new BadRequestException(`${name.toUpperCase()}_TOO_LONG`);
    }
    const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    if (!uuidPattern.test(input.playerId)) throw new BadRequestException('PLAYER_ID_INVALID');
    if (!uuidPattern.test(input.walletId)) throw new BadRequestException('WALLET_ID_INVALID');
    let money: Money;
    try { money = Money.from(input.money); }
    catch (error) { throw new BadRequestException((error as Error).message || 'INVALID_MONEY'); }
    if (!money.isPositive()) throw new BadRequestException('AMOUNT_MUST_BE_POSITIVE');
    if ((input.kind === 'REFUND' || input.kind === 'ROLLBACK') && (!input.referenceExternalTransactionId || !input.referenceExternalTransactionId.trim())) throw new BadRequestException('REFERENCE_REQUIRED');
    if (input.kind === 'WIN' && typeof input.referenceExternalTransactionId === 'string' && !input.referenceExternalTransactionId.trim()) throw new BadRequestException('REFERENCE_INVALID');
    if (input.referenceExternalTransactionId && input.referenceExternalTransactionId.length > 255) throw new BadRequestException('REFERENCE_TOO_LONG');
    if (input.referenceExternalTransactionId && !['WIN', 'REFUND', 'ROLLBACK'].includes(input.kind)) throw new BadRequestException('REFERENCE_NOT_ALLOWED_FOR_KIND');
    if (input.referenceExternalTransactionId && input.referenceExternalTransactionId === input.externalTransactionId) throw new BadRequestException('SELF_REFERENCE_NOT_ALLOWED');
    const normalizedInput: WagerInput = { ...input, money: money.toJSON(), ...(input.referenceExternalTransactionId ? { referenceExternalTransactionId: input.referenceExternalTransactionId } : {}) };
    const businessPayload = {
      providerId: normalizedInput.providerId,
      externalTransactionId: normalizedInput.externalTransactionId,
      playerId: normalizedInput.playerId,
      walletId: normalizedInput.walletId,
      roundId: normalizedInput.roundId,
      gameId: normalizedInput.gameId,
      kind: normalizedInput.kind,
      money: normalizedInput.money,
      referenceExternalTransactionId: normalizedInput.referenceExternalTransactionId ?? null,
    };
    return { input: normalizedInput, key: idempotencyKey, money, payloadHash: sha256(businessPayload) };
  }

  private parseQueueEnvelope(value: unknown): { input: WagerInput; key: string } {
    if (!value || typeof value !== 'object') throw new BadRequestException('INVALID_QUEUE_ENVELOPE');
    const envelope = value as Record<string, any>;
    if (envelope.type !== 'WagerTransactionRequested' || !envelope.data || typeof envelope.data !== 'object') throw new BadRequestException('INVALID_QUEUE_MESSAGE_TYPE');
    const data = envelope.data as WagerInput & { idempotencyKey?: string };
    return { input: data, key: data.idempotencyKey ?? `${data.providerId}:${data.externalTransactionId}` };
  }

  private async processInTransaction(tx: EntityManager, prepared: PreparedWager): Promise<WagerResult> {
    const { input, key, money, payloadHash } = prepared;
    const existing = await tx.findOne(WagerTransactionEntity, { idempotencyKey: key });
    if (existing) {
      if (existing.payloadHash !== payloadHash) throw new ConflictException('IDEMPOTENCY_KEY_PAYLOAD_CONFLICT');
      return this.responseFor(existing, true);
    }
    const externalExisting = await tx.findOne(WagerTransactionEntity, { providerId: input.providerId, externalTransactionId: input.externalTransactionId });
    if (externalExisting) throw new ConflictException('EXTERNAL_TRANSACTION_ID_CONFLICT');

    // Pessimistic lock is scoped to one wallet. Different wallets continue in parallel.
    const walletRow = await tx.findOne(WalletEntity, { id: input.walletId }, { lockMode: LockMode.PESSIMISTIC_WRITE });
    if (!walletRow) throw new NotFoundException('WALLET_NOT_FOUND');
    if (walletRow.playerId !== input.playerId) throw new BadRequestException('WALLET_PLAYER_MISMATCH');
    if (walletRow.currency !== money.currency) throw new BadRequestException('WALLET_CURRENCY_MISMATCH');
    const afterLock = await tx.findOne(WagerTransactionEntity, { idempotencyKey: key });
    if (afterLock) {
      if (afterLock.payloadHash !== payloadHash) throw new ConflictException('IDEMPOTENCY_KEY_PAYLOAD_CONFLICT');
      return this.responseFor(afterLock, true);
    }
    const afterLockExternal = await tx.findOne(WagerTransactionEntity, { providerId: input.providerId, externalTransactionId: input.externalTransactionId });
    if (afterLockExternal) throw new ConflictException('EXTERNAL_TRANSACTION_ID_CONFLICT');

    const now = new Date();
    const id = randomUUID();
    let domainTransaction: WagerTransaction;
    try {
      domainTransaction = WagerTransaction.create({
        id, providerId: input.providerId, externalTransactionId: input.externalTransactionId,
        idempotencyKey: key, payloadHash, walletId: input.walletId, playerId: input.playerId,
        roundId: input.roundId, gameId: input.gameId, kind: input.kind as WagerKind,
        money, referenceExternalTransactionId: input.referenceExternalTransactionId, createdAt: now,
      });
    } catch (error) { throw new BadRequestException((error as Error).message); }
    const wagerRow = tx.create(WagerTransactionEntity, {
      id, providerId: input.providerId, externalTransactionId: input.externalTransactionId,
      idempotencyKey: key, payloadHash, walletId: input.walletId, playerId: input.playerId,
      roundId: input.roundId, gameId: input.gameId, kind: input.kind, amount: money.toString(),
      currency: money.currency, referenceExternalTransactionId: input.referenceExternalTransactionId,
      status: WagerStatus.Pending, createdAt: now, referenceAttempts: 0,
    });
    tx.persist(wagerRow);
    await tx.flush(); // establishes FK target before an optional ledger entry, while remaining inside this transaction

    const wallet = this.rehydrateWallet(walletRow);
    const evaluation = await this.evaluateAndPersist(tx, domainTransaction, wagerRow, walletRow, wallet, now, true);
    const response: WagerResult = {
      transactionId: id, status: wagerRow.status, balance: evaluation.balance.toJSON(), idempotentReplay: false,
      ...(wagerRow.failureCode ? { failureCode: wagerRow.failureCode } : {}),
    };
    wagerRow.originalResponse = response;
    await tx.flush();
    return response;
  }

  private async evaluateAndPersist(
    tx: EntityManager, domainTransaction: WagerTransaction, wagerRow: WagerTransactionEntity,
    walletRow: WalletEntity, wallet: Wallet, now: Date, emitPendingEvent: boolean,
  ): Promise<Evaluation> {
    const inputKind = domainTransaction.kind;
    let reference: WagerTransactionEntity | null = null;
    let direction: LedgerDirection | undefined;
    let failureCode: FailureCode | undefined;

    const hasOptionalWinReference = inputKind === WagerKind.Win && Boolean(domainTransaction.referenceExternalTransactionId);
    const isReversal = inputKind === WagerKind.Refund || inputKind === WagerKind.Rollback;
    const deferForReference = (): Evaluation => {
      domainTransaction.markPendingReference();
      wagerRow.status = WagerStatus.PendingReference;
      wagerRow.referenceAttempts = wagerRow.referenceAttempts ?? 0;
      wagerRow.nextReferenceAttemptAt = new Date(now.getTime() + 1000);
      this.syncTransaction(domainTransaction, wagerRow);
      if (emitPendingEvent) this.persistEvent(tx, WagerTransactionPendingReference.create({
        aggregateId: wagerRow.id, correlationId: wagerRow.id, occurredAt: now,
        data: { transactionId: wagerRow.id, providerId: wagerRow.providerId, externalTransactionId: wagerRow.externalTransactionId, referenceExternalTransactionId: wagerRow.referenceExternalTransactionId },
      }));
      return { pendingReference: true, balance: wallet.balance };
    };

    if (isReversal || hasOptionalWinReference) {
      reference = await tx.findOne(WagerTransactionEntity, {
        providerId: domainTransaction.providerId,
        externalTransactionId: domainTransaction.referenceExternalTransactionId,
      });
      if (!reference) return deferForReference();

      // Validate immutable facts (kind, ownership/scope, exact reversal amount) as soon as
      // the reference exists, even if its own processing is still pending. Invalid references
      // should not consume the retry window or be misreported as merely not-yet-processed.
      wagerRow.referenceTransactionId = reference.id;
      const sameScope = reference.walletId === wagerRow.walletId
        && reference.playerId === wagerRow.playerId
        && reference.currency === wagerRow.currency
        && reference.roundId === wagerRow.roundId
        && reference.providerId === wagerRow.providerId;

      if (inputKind === WagerKind.Win) {
        if (reference.kind !== WagerKind.Bet) failureCode = 'INVALID_REFERENCE_KIND';
        else if (!sameScope) failureCode = 'REFERENCE_MISMATCH';
      } else {
        const expectedKind = inputKind === WagerKind.Refund
          ? reference.kind === WagerKind.Bet
          : ['BET', 'WIN', 'REFUND'].includes(reference.kind);
        if (!expectedKind) failureCode = 'INVALID_REFERENCE_KIND';
        else if (!sameScope || !this.amountsEqual(reference.amount, reference.currency, wagerRow.amount, wagerRow.currency)) failureCode = 'REFERENCE_MISMATCH';
      }

      if (!failureCode && [WagerStatus.PendingReference, WagerStatus.Pending].includes(reference.status as WagerStatus)) {
        return deferForReference();
      }
      if (!failureCode && reference.status !== WagerStatus.Processed) failureCode = 'REFERENCE_NOT_PROCESSED';

      if (!failureCode) {
        if (inputKind === WagerKind.Win) {
          // WIN amount is a payout and need not equal the referenced BET amount.
          direction = LedgerDirection.Credit;
        } else {
          const reversed = await tx.findOne(WagerTransactionEntity, { referenceTransactionId: reference.id, kind: inputKind, status: WagerStatus.Processed });
          if (reversed) failureCode = 'REFERENCE_ALREADY_REVERSED';
          else direction = reference.kind === WagerKind.Bet ? LedgerDirection.Credit : LedgerDirection.Debit;
        }
      }
    } else if (inputKind === WagerKind.Bet) direction = LedgerDirection.Debit;
    else if (inputKind === WagerKind.Win) direction = LedgerDirection.Credit;
    else if (inputKind === WagerKind.Loss) direction = undefined;

    if (failureCode) {
      domainTransaction.reject(failureCode, now, reference?.id);
      this.syncTransaction(domainTransaction, wagerRow);
      this.persistRejectedEvent(tx, wagerRow, now);
      return { pendingReference: false, balance: wallet.balance };
    }

    let ledgerEntry: WalletLedgerEntry | undefined;
    if (direction) {
      try {
        ledgerEntry = direction === LedgerDirection.Debit
          ? wallet.debit({ transactionId: wagerRow.id, money: Money.from({ amount: wagerRow.amount, currency: wagerRow.currency }), now })
          : wallet.credit({ transactionId: wagerRow.id, money: Money.from({ amount: wagerRow.amount, currency: wagerRow.currency }), now });
      } catch (error) {
        const code = error instanceof DomainError ? error.code : error instanceof Error ? error.message : undefined;
        if (code === 'INSUFFICIENT_FUNDS') {
          const rejection: FailureCode = inputKind === WagerKind.Bet ? 'INSUFFICIENT_FUNDS' : 'REVERSAL_BALANCE_NEGATIVE';
          domainTransaction.reject(rejection, now, reference?.id);
          this.syncTransaction(domainTransaction, wagerRow);
          this.persistRejectedEvent(tx, wagerRow, now);
          return { pendingReference: false, balance: wallet.balance };
        }
        if (code === 'MONEY_OVERFLOW') {
          domainTransaction.reject('WALLET_BALANCE_LIMIT_EXCEEDED', now, reference?.id);
          this.syncTransaction(domainTransaction, wagerRow);
          this.persistRejectedEvent(tx, wagerRow, now);
          return { pendingReference: false, balance: wallet.balance };
        }
        throw error;
      }
      walletRow.balance = wallet.balance.toString();
      walletRow.version = wallet.version;
      walletRow.updatedAt = wallet.updatedAt;
      tx.persist(tx.create(LedgerEntryEntity, {
        id: ledgerEntry.id, walletId: ledgerEntry.walletId, transactionId: ledgerEntry.transactionId,
        direction: ledgerEntry.direction, amount: ledgerEntry.money.toString(),
        balanceBefore: ledgerEntry.balanceBefore.toString(), balanceAfter: ledgerEntry.balanceAfter.toString(),
        currency: ledgerEntry.money.currency, walletVersion: ledgerEntry.walletVersion, createdAt: ledgerEntry.createdAt,
      }));
      this.persistEvent(tx, WalletBalanceChanged.create({
        aggregateId: wallet.id, correlationId: wagerRow.id, causationId: wagerRow.id, occurredAt: now,
        data: { walletId: wallet.id, transactionId: wagerRow.id, direction, money: ledgerEntry.money.toJSON(),
          balanceBefore: ledgerEntry.balanceBefore.toJSON(), balanceAfter: ledgerEntry.balanceAfter.toJSON(), walletVersion: ledgerEntry.walletVersion },
      }));
    }

    domainTransaction.markProcessed(reference?.id, now);
    this.syncTransaction(domainTransaction, wagerRow);
    this.persistEvent(tx, WagerTransactionProcessed.create({
      aggregateId: wagerRow.id, correlationId: wagerRow.id, occurredAt: now,
      data: { transactionId: wagerRow.id, providerId: wagerRow.providerId, externalTransactionId: wagerRow.externalTransactionId,
        kind: wagerRow.kind, status: WagerStatus.Processed },
    }));
    return { pendingReference: false, balance: wallet.balance };
  }

  private async retryOnePendingReference(tx: EntityManager, row: WagerTransactionEntity, now: Date): Promise<void> {
    this.metrics.retry('pending_reference');
    const walletRow = await tx.findOne(WalletEntity, { id: row.walletId }, { lockMode: LockMode.PESSIMISTIC_WRITE });
    if (!walletRow) {
      row.status = WagerStatus.Rejected; row.failureCode = 'WALLET_NOT_FOUND'; row.processedAt = now; row.nextReferenceAttemptAt = undefined;
      this.persistRejectedEvent(tx, row, now);
      row.originalResponse = { transactionId: row.id, status: row.status, balance: null, idempotentReplay: false, failureCode: row.failureCode };
      return;
    }
    const domainTransaction = this.toDomainWager(row);
    const wallet = this.rehydrateWallet(walletRow);

    // Evaluate reference before consuming another retry. If still absent, keep exponential backoff.
    const reference = await tx.findOne(WagerTransactionEntity, { providerId: row.providerId, externalTransactionId: row.referenceExternalTransactionId });
    if (!reference) {
      row.referenceAttempts += 1;
      const maxAttempts = Math.max(1, Math.min(50, Number(process.env.PENDING_REFERENCE_MAX_ATTEMPTS ?? 8)));
      if (row.referenceAttempts >= maxAttempts) {
        domainTransaction.reject('REFERENCE_NOT_FOUND', now);
        this.syncTransaction(domainTransaction, row);
        row.nextReferenceAttemptAt = undefined;
        this.persistRejectedEvent(tx, row, now);
        row.originalResponse = { transactionId: row.id, status: row.status, balance: wallet.balance.toJSON(), idempotentReplay: false, failureCode: row.failureCode };
      } else {
        row.nextReferenceAttemptAt = new Date(now.getTime() + Math.min(300_000, 1000 * 2 ** Math.min(row.referenceAttempts, 8)));
      }
      return;
    }

    // The reference may exist but itself be waiting for another reference (e.g. rollback of a pending refund).
    const maxAttempts = Math.max(1, Math.min(50, Number(process.env.PENDING_REFERENCE_MAX_ATTEMPTS ?? 8)));
    if (reference.status === WagerStatus.PendingReference || reference.status === WagerStatus.Pending) {
      row.referenceAttempts += 1;
      if (row.referenceAttempts >= maxAttempts) {
        domainTransaction.reject('REFERENCE_NOT_PROCESSED', now, reference.id);
        this.syncTransaction(domainTransaction, row);
        row.nextReferenceAttemptAt = undefined;
        this.persistRejectedEvent(tx, row, now);
        row.originalResponse = { transactionId: row.id, status: row.status, balance: wallet.balance.toJSON(), idempotentReplay: false, failureCode: row.failureCode };
      } else {
        row.referenceTransactionId = reference.id;
        row.nextReferenceAttemptAt = new Date(now.getTime() + Math.min(300_000, 1000 * 2 ** Math.min(row.referenceAttempts, 8)));
      }
      return;
    }

    // A processed reference arrived: execute the same financial use case used by HTTP/SQS ingress.
    row.referenceTransactionId = reference.id;
    row.status = WagerStatus.Pending;
    row.nextReferenceAttemptAt = undefined;
    const evaluation = await this.evaluateAndPersist(tx, domainTransaction, row, walletRow, wallet, now, false);
    if (evaluation.pendingReference) {
      // Defensive path; the lookup above already found the reference.
      row.status = WagerStatus.PendingReference;
      row.nextReferenceAttemptAt = new Date(now.getTime() + 1000);
      return;
    }
    row.originalResponse = {
      transactionId: row.id, status: row.status, balance: evaluation.balance.toJSON(), idempotentReplay: false,
      ...(row.failureCode ? { failureCode: row.failureCode } : {}),
    };
    await tx.flush();
  }

  private rehydrateWallet(row: WalletEntity): Wallet {
    return Wallet.rehydrate({ id: row.id, playerId: row.playerId, currency: row.currency, balance: Money.from({ amount: row.balance, currency: row.currency }), version: row.version, createdAt: row.createdAt, updatedAt: row.updatedAt });
  }

  private toDomainWager(row: WagerTransactionEntity): WagerTransaction {
    return WagerTransaction.rehydrate({ id: row.id, providerId: row.providerId, externalTransactionId: row.externalTransactionId,
      idempotencyKey: row.idempotencyKey, payloadHash: row.payloadHash, walletId: row.walletId, playerId: row.playerId,
      roundId: row.roundId, gameId: row.gameId, kind: row.kind as WagerKind, money: Money.from({ amount: row.amount, currency: row.currency }),
      referenceExternalTransactionId: row.referenceExternalTransactionId, createdAt: row.createdAt, status: row.status as WagerStatus,
      referenceTransactionId: row.referenceTransactionId, failureCode: row.failureCode as FailureCode | undefined, processedAt: row.processedAt });
  }

  private syncTransaction(domain: WagerTransaction, row: WagerTransactionEntity): void {
    row.status = domain.status;
    row.referenceTransactionId = domain.referenceTransactionId;
    row.failureCode = domain.failureCode;
    row.processedAt = domain.processedAt;
    if (domain.status !== WagerStatus.PendingReference) row.nextReferenceAttemptAt = undefined;
  }

  private persistRejectedEvent(tx: EntityManager, row: WagerTransactionEntity, now: Date): void {
    this.persistEvent(tx, WagerTransactionRejected.create({
      aggregateId: row.id, correlationId: row.id, occurredAt: now,
      data: { transactionId: row.id, providerId: row.providerId, externalTransactionId: row.externalTransactionId, kind: row.kind, status: WagerStatus.Rejected, failureCode: row.failureCode ?? 'INVALID_OPERATION' },
    }));
  }

  private persistEvent(tx: EntityManager, event: AnyIntegrationEvent): void {
    const payload = event.toJSON() as Record<string, unknown>;
    tx.persist(tx.create(OutboxMessageEntity, { id: event.eventId, aggregateId: event.aggregateId, eventType: event.eventType, payload, createdAt: event.occurredAt, attempts: 0 }));
  }

  private responseFor(row: WagerTransactionEntity, replay: boolean): WagerResult {
    if (row.originalResponse) return { ...(row.originalResponse as unknown as WagerResult), idempotentReplay: replay };
    return { transactionId: row.id, status: row.status, balance: null, idempotentReplay: replay, ...(row.failureCode ? { failureCode: row.failureCode } : {}) };
  }

  private async recoverUniqueConflict(prepared: PreparedWager): Promise<WagerResult> {
    // Use a clean fork: this method can execute from non-HTTP worker contexts.
    const lookup = this.em.fork({ clear: true });
    const winner = await lookup.findOne(WagerTransactionEntity, { idempotencyKey: prepared.key });
    if (winner) {
      if (winner.payloadHash !== prepared.payloadHash) throw new ConflictException('IDEMPOTENCY_KEY_PAYLOAD_CONFLICT');
      this.metrics.duplicate('idempotency_key');
      return this.responseFor(winner, true);
    }
    const external = await lookup.findOne(WagerTransactionEntity, { providerId: prepared.input.providerId, externalTransactionId: prepared.input.externalTransactionId });
    if (external) throw new ConflictException('EXTERNAL_TRANSACTION_ID_CONFLICT');
    throw new ConflictException('UNIQUE_CONSTRAINT_CONFLICT');
  }

  private async withDatabaseRetry<T>(operation: () => Promise<T>): Promise<T> {
    const maxRetries = 3;
    for (let attempt = 0; ; attempt++) {
      try { return await operation(); }
      catch (error) {
        if (!isRetryableDatabaseConflict(error) || attempt >= maxRetries) throw error;
        this.metrics.retry('database_lock');
        await new Promise(resolve => setTimeout(resolve, 20 * (2 ** attempt)));
      }
    }
  }

  private amountsEqual(leftAmount: string, leftCurrency: string, rightAmount: string, rightCurrency: string): boolean {
    if (leftCurrency !== rightCurrency) return false;
    try { return Money.from({ amount: new Decimal(leftAmount).toFixed(2), currency: leftCurrency }).equals(Money.from({ amount: new Decimal(rightAmount).toFixed(2), currency: rightCurrency })); }
    catch { return false; }
  }

  private isConnectionFailure(error: unknown): boolean {
    const connectionCodes = new Set(['08000', '08001', '08003', '08004', '08006', '08007', '08P01', '57P01', '57P02', '57P03', 'ECONNREFUSED', 'ECONNRESET', 'ETIMEDOUT', 'EPIPE', 'EHOSTUNREACH', 'ENETUNREACH']);
    let current: any = error;
    while (current) {
      if (typeof current.code === 'string' && connectionCodes.has(current.code)) return true;
      const message = typeof current.message === 'string' ? current.message : '';
      if (/connection terminated unexpectedly|connection is closed|connect ECONNREFUSED|timeout expired/i.test(message)) return true;
      current = current.cause;
    }
    return false;
  }

  private toPublicTransaction(row: WagerTransactionEntity) {
    return {
      transactionId: row.id, providerId: row.providerId, externalTransactionId: row.externalTransactionId,
      playerId: row.playerId, walletId: row.walletId, roundId: row.roundId, gameId: row.gameId,
      kind: row.kind, money: { amount: row.amount, currency: row.currency },
      ...(row.referenceExternalTransactionId ? { referenceExternalTransactionId: row.referenceExternalTransactionId } : {}),
      ...(row.referenceTransactionId ? { referenceTransactionId: row.referenceTransactionId } : {}),
      status: row.status, ...(row.failureCode ? { failureCode: row.failureCode } : {}),
      createdAt: row.createdAt, processedAt: row.processedAt ?? null,
    };
  }
}

