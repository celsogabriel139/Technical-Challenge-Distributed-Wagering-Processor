import { Injectable } from '@nestjs/common';
import { Counter, Gauge, Histogram, Registry, collectDefaultMetrics } from 'prom-client';

@Injectable()
export class MetricsService {
  readonly registry = new Registry();
  private readonly transactions: Counter<string>;
  private readonly duplicates: Counter<string>;
  private readonly retries: Counter<string>;
  private readonly dlq: Counter<string>;
  private readonly lockConflicts: Counter<string>;
  private readonly reconciliationMismatches: Counter<string>;
  private readonly processingDuration: Histogram<string>;
  private readonly outboxLag: Gauge<string>;

  constructor() {
    if (process.env.NODE_ENV !== 'test') collectDefaultMetrics({ register: this.registry });
    this.transactions = new Counter({ name: 'wager_transactions_total', help: 'Wager transaction outcomes', labelNames: ['status'], registers: [this.registry] });
    this.duplicates = new Counter({ name: 'wager_duplicates_total', help: 'Persistent duplicate detections', labelNames: ['source'], registers: [this.registry] });
    this.retries = new Counter({ name: 'wager_retries_total', help: 'Worker retry attempts', labelNames: ['worker'], registers: [this.registry] });
    this.dlq = new Counter({ name: 'wager_dlq_messages_total', help: 'Messages routed to a dead-letter queue', labelNames: ['reason'], registers: [this.registry] });
    this.lockConflicts = new Counter({ name: 'wager_lock_conflicts_total', help: 'Database concurrency conflicts', labelNames: ['code'], registers: [this.registry] });
    this.reconciliationMismatches = new Counter({ name: 'wager_reconciliation_mismatches_total', help: 'Wallet reconciliation mismatches', registers: [this.registry] });
    this.processingDuration = new Histogram({ name: 'wager_processing_duration_seconds', help: 'Duration of wager use-case processing', labelNames: ['kind', 'status'], buckets: [0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5], registers: [this.registry] });
    this.outboxLag = new Gauge({ name: 'wager_outbox_oldest_pending_age_seconds', help: 'Age of oldest unpublished outbox event', registers: [this.registry] });
  }

  transaction(status: string) { this.transactions.inc({ status }); }
  duplicate(source: string) { this.duplicates.inc({ source }); }
  retry(worker: string) { this.retries.inc({ worker }); }
  deadLetter(reason: string) { this.dlq.inc({ reason }); }
  lockConflict(code: string) { this.lockConflicts.inc({ code }); }
  reconciliationMismatch() { this.reconciliationMismatches.inc(); }
  startProcessingTimer(kind: string) { return this.processingDuration.startTimer({ kind }); }
  finishProcessingTimer(end: (labels?: Record<string, string>) => number, status: string) { end({ status }); }
  setOutboxLag(seconds: number) { this.outboxLag.set(Math.max(0, seconds)); }
  async metricsText(): Promise<string> { return this.registry.metrics(); }
}
