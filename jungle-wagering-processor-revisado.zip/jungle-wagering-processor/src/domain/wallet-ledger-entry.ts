import { Money } from './money';
import { DomainError, LedgerDirection } from './wager.types';

export interface LedgerEntryState {
  id: string; walletId: string; transactionId: string; direction: LedgerDirection; money: Money;
  balanceBefore: Money; balanceAfter: Money; walletVersion: number; createdAt: Date;
}

/** Immutable audit record. Its factory proves the balance arithmetic before persistence. */
export class WalletLedgerEntry {
  private constructor(
    public readonly id: string,
    public readonly walletId: string,
    public readonly transactionId: string,
    public readonly direction: LedgerDirection,
    public readonly money: Money,
    public readonly balanceBefore: Money,
    public readonly balanceAfter: Money,
    public readonly walletVersion: number,
    public readonly createdAt: Date,
  ) {}

  static create(props: LedgerEntryState): WalletLedgerEntry {
    if (!props.money.isPositive()) throw new DomainError('LEDGER_AMOUNT_MUST_BE_POSITIVE');
    if (props.balanceBefore.currency !== props.money.currency || props.balanceAfter.currency !== props.money.currency) throw new DomainError('CURRENCY_MISMATCH');
    if (props.balanceBefore.isNegative() || props.balanceAfter.isNegative()) throw new DomainError('LEDGER_BALANCE_CANNOT_BE_NEGATIVE');
    if (props.direction !== LedgerDirection.Debit && props.direction !== LedgerDirection.Credit) throw new DomainError('INVALID_LEDGER_DIRECTION');
    if (!Number.isInteger(props.walletVersion) || props.walletVersion < 1) throw new DomainError('INVALID_WALLET_VERSION');
    if (props.direction === LedgerDirection.Debit && !props.balanceBefore.subtract(props.money).equals(props.balanceAfter)) throw new DomainError('UNBALANCED_LEDGER_ENTRY');
    if (props.direction === LedgerDirection.Credit && !props.balanceBefore.add(props.money).equals(props.balanceAfter)) throw new DomainError('UNBALANCED_LEDGER_ENTRY');
    return new WalletLedgerEntry(props.id, props.walletId, props.transactionId, props.direction, props.money, props.balanceBefore, props.balanceAfter, props.walletVersion, props.createdAt);
  }

  static rehydrate(state: LedgerEntryState): WalletLedgerEntry {
    return new WalletLedgerEntry(state.id, state.walletId, state.transactionId, state.direction, state.money, state.balanceBefore, state.balanceAfter, state.walletVersion, state.createdAt);
  }

  isBalanced(): boolean {
    try {
      const calculated = this.direction === LedgerDirection.Credit ? this.balanceBefore.add(this.money) : this.balanceBefore.subtract(this.money);
      return calculated.equals(this.balanceAfter);
    } catch { return false; }
  }
}
