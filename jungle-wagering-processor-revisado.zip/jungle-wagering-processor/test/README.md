# Test strategy

Run `bun test test/unit` for domain tests. Add/run integration tests only against PostgreSQL and LocalStack containers; the challenge explicitly disallows replacing these systems entirely with mocks. The minimum acceptance suite should include:
- same idempotency key sent 50 times concurrently;
- two simultaneous 80.00 BETs against 100.00;
- distinct wallets in parallel;
- three or more API/worker processes;
- crash after commit before SQS ack;
- two outbox publishers racing;
- refund/rollback before reference;
- restart and ledger reconciliation.
