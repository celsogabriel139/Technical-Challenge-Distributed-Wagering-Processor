import { Entity, PrimaryKey, Property, Unique, Index } from '@mikro-orm/core';

@Entity({ tableName: 'wallet_ledger_entries' })
@Unique({ properties: ['walletId', 'transactionId'] })
@Unique({ properties: ['transactionId'] })
@Index({ properties: ['walletId', 'createdAt', 'id'] })
export class LedgerEntryEntity {
  @PrimaryKey({ type: 'uuid' }) id!: string;
  @Property({ type: 'uuid' }) walletId!: string;
  @Property({ type: 'uuid' }) transactionId!: string;
  @Property() direction!: string;
  @Property({ columnType: 'numeric(20,2)' }) amount!: string;
  @Property({ columnType: 'numeric(20,2)' }) balanceBefore!: string;
  @Property({ columnType: 'numeric(20,2)' }) balanceAfter!: string;
  @Property() currency!: string;
  @Property({ columnType: 'int' }) walletVersion!: number;
  @Property() createdAt: Date = new Date();
}
