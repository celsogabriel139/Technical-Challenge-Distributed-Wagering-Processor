import { createServer, Server } from 'node:http';
import { MetricsService } from './modules/metrics/metrics.service';

/** Small per-process scrape endpoint so worker metrics are visible, not trapped in memory. */
export async function startMetricsServer(metrics: MetricsService, port: number, component: string): Promise<Server> {
  const server = createServer(async (request, response) => {
    const path = (request.url ?? '/').split('?', 1)[0];
    if (request.method === 'GET' && path === '/health/live') {
      response.writeHead(200, { 'content-type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ status: 'ok', component }));
      return;
    }
    if (request.method === 'GET' && path === '/metrics') {
      try {
        const body = await metrics.metricsText();
        response.writeHead(200, { 'content-type': metrics.registry.contentType });
        response.end(body);
      } catch (error) {
        response.writeHead(500, { 'content-type': 'text/plain; charset=utf-8' });
        response.end('metrics_unavailable');
      }
      return;
    }
    response.writeHead(404, { 'content-type': 'application/json; charset=utf-8' });
    response.end(JSON.stringify({ error: 'NOT_FOUND' }));
  });

  await new Promise<void>((resolve, reject) => {
    const onError = (error: Error) => reject(error);
    server.once('error', onError);
    server.listen(port, '0.0.0.0', () => {
      server.off('error', onError);
      resolve();
    });
  });
  console.log(JSON.stringify({ level: 'info', message: 'worker_metrics_started', component, port }));
  return server;
}

export async function stopMetricsServer(server: Server): Promise<void> {
  await new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
}
