# Distributed Wagering Processor

Referência de implementação para o **Technical Challenge — Distributed Wagering Processor** da Jungle Gaming. A stack segue Bun 1.x, TypeScript estrito, NestJS, PostgreSQL, MikroORM, AWS SQS/LocalStack e Docker Compose.

## Pré-requisitos

- Bun 1.x
- Docker Engine + Docker Compose plugin

## Subida local completa

```bash
cp .env.example .env
bun install
docker compose up --build -d
```

O Compose sobe PostgreSQL e LocalStack, inicializa as quatro filas FIFO, executa a migration e inicia API, consumidor SQS, publisher da outbox e worker de referências pendentes. A API fica em `http://localhost:3000`.

Verifique `GET /health/live`, `GET /health/ready` e `GET /metrics` na API. Cada worker também expõe `/metrics` e `/health/live` na rede Docker: `worker:3001`, `outbox-worker:3002` e `pending-reference-worker:3003`, para que suas métricas locais também possam ser coletadas.

Para ver logs: `docker compose logs -f api worker outbox-worker pending-reference-worker`. Para parar: `docker compose down`. Para apagar os dados locais, inclusive o ledger: `docker compose down -v` (**destrutivo**).

## Endpoints

| Método | Endpoint | Finalidade |
|---|---|---|
| `POST` | `/wallets` | Abre carteira; saldo inicial positivo gera `OPENING` + ledger |
| `GET` | `/wallets/:walletId` | Saldo e versão materializados |
| `GET` | `/wallets/:walletId/ledger?limit=50&cursor=...` | Ledger imutável paginado por cursor |
| `POST` | `/wallets/:walletId/reconciliation` | Compara saldo com reconstrução do ledger sem corrigir silenciosamente |
| `POST` | `/wagering/transactions` | Executa `BET`, `WIN`, `LOSS`, `REFUND` ou `ROLLBACK` |
| `GET` | `/wagering/transactions/:transactionId` | Consulta por UUID interno |
| `GET` | `/providers/:providerId/wagering/transactions/:externalTransactionId` | Consulta por identidade externa do provedor |
| `GET` | `/health/live` | Liveness, sem chamadas externas |
| `GET` | `/health/ready` | Readiness: PostgreSQL e SQS |
| `GET` | `/metrics` | Métricas Prometheus |

`POST /wagering/transactions` exige `Idempotency-Key`. IDs `playerId` e `walletId` devem ser UUIDs. Dinheiro é enviado como string com duas casas decimais, por exemplo `{"amount":"25.00","currency":"BRL"}`.

### Exemplos

Crie uma carteira (substitua pelo UUID real de jogador):

```bash
curl -X POST http://localhost:3000/wallets \
  -H 'content-type: application/json' \
  -d '{"playerId":"0192f28f-5dc0-7d58-bdb2-814ad6a0f4a1","initialBalance":{"amount":"100.00","currency":"BRL"}}'
```

Use o `id` retornado como `walletId`:

```bash
curl -X POST http://localhost:3000/wagering/transactions \
  -H 'content-type: application/json' \
  -H 'Idempotency-Key: provider-a:bet-1' \
  -d '{"providerId":"provider-a","externalTransactionId":"bet-1","playerId":"0192f28f-5dc0-7d58-bdb2-814ad6a0f4a1","walletId":"COLOQUE-UUID-DA-CARTEIRA","roundId":"round-1","gameId":"game-1","kind":"BET","money":{"amount":"25.00","currency":"BRL"}}'
```

### Regras e respostas

- `PROCESSED`: efeito financeiro confirmado; `LOSS` não gera movimento no saldo.
- `PENDING_REFERENCE`: `REFUND`/`ROLLBACK` e `WIN` com referência opcional esperam a referência e são reprocessados com backoff pelo worker.
- `REJECTED`: rejeição de negócio com `failureCode` estável.
- Mesmo `Idempotency-Key` + mesmo payload: replay persistente do resultado original. Mesmo key + payload diferente: `409 Conflict`.
- `WIN` aceita uma referência opcional a uma `BET`; se informada, aguarda uma referência fora de ordem, valida provedor/jogador/carteira/moeda/rodada e exige que a referência seja uma `BET` processada. O pagamento pode ter valor diferente da aposta. Uma reversão é aplicada uma vez por tipo/referência, deve ter valor idêntico e a referência deve pertencer ao mesmo provedor, jogador, carteira, moeda e rodada.
- `OPENING` é interno e não é aceito pela API nem pela fila.

## Testes

Testes unitários de domínio e Money:

```bash
bun run test:unit
```

Testes de integração reais (não mocks de PostgreSQL/SQS):

```bash
cp .env.example .env
bun install
docker compose up -d postgres localstack
bun run init:sqs
bun run migration:up
bun run test:integration
```

`test:integration` compila o serviço e executa cenários contra PostgreSQL e LocalStack, inclusive 50 reenvios paralelos, corrida de saldo insuficiente, três processos Bun, inbox/redelivery, referência fora de ordem, publicação concorrente da outbox, DLQ e imutabilidade do ledger. Os testes são intencionalmente excluídos da inicialização padrão e só executam quando chamados explicitamente. O ambiente deve estar limpo e ser dedicado aos testes: o teste de concorrência da outbox limpa suas linhas de eventos.

Verificação local completa de tipo + unitários: `bun run test:all`. Migrações: `bun run migration:up` e `bun run migration:down` (down é destrutivo).

## Decisões e limites de escopo

Leia [`ARCHITECTURE.md`](./ARCHITECTURE.md). A autenticação é o único item explicitamente fora da implementação funcional: há `ProviderIdentityGuard` como ponto de extensão no-op, permitido pelo enunciado. Antes de produção, substitua-o por integração OIDC com Identity Provider externo, configure segredos reais, alertas e retenção operacional. Publicação na SQS é at-least-once: consumidores de eventos devem deduplicar pelo `eventId`; não é possível prometer entrega exatamente uma vez entre PostgreSQL e SQS.
